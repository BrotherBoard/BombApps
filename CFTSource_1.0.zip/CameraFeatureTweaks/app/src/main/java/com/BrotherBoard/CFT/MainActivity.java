package com.BrotherBoard.CFT;
 
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import android.os.CountDownTimer;
import java.util.concurrent.CountDownLatch;

public class MainActivity extends Activity {
    // methods
    public String exec(String in, int silent) {
        String out = ""; String n = "\n";
        try {
            Process su = Runtime.getRuntime().exec("su");
            DataOutputStream outputStream = new DataOutputStream(su.getOutputStream());
            outputStream.writeBytes("mount -o rw,remount /" + n + in + n);
            outputStream.flush();
            outputStream.writeBytes("exit\n");
            outputStream.flush();
            BufferedReader inputStream = new BufferedReader(new InputStreamReader(su.getInputStream()));
            String line;
            while ((line = inputStream.readLine()) != null) {
                out += line + n;
            }
            su.waitFor();
        } catch (IOException e) {} catch (InterruptedException e) {}

        if (silent == 0) {
            ipush(out);
        }
        return out;
    }
    
    public String exec_user(String command) {
        String out = "";
        try{
            Process process = Runtime.getRuntime().exec(command);
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            out=reader.readLine();
        } catch (IOException e) {}
        return out;
    }
    
    public void ipush(String toPush) {
        EditText logbox = findViewById(R.id.logbox);
        String old = logbox.getText().toString();
        logbox.setText(old+"\n"+toPush);
    }
    
    public void bqp() {
        String root = getFilesDir().getAbsolutePath();
        String file = "camera-feature.xml";
        String xml = "/system/cameradata/"+file;
        String s = " ";
        exec("cp "+xml+s+root+s, 1);
        ipush("CFT: backup was created in "+root);
    }
    
    public String getFeature(String feature) {
        String out = "";
        String xml="/system/cameradata/camera-feature.xml";
        out=exec("su -c cat "+xml+" | grep "+feature, 1);
        return out;
    }
    
    public void rstore() {
        new CountDownTimer(500, 500) {
            @Override
            public void onTick(long p1) {
            }
            @Override
            public void onFinish() {
                String s = " "; String sl = "/";
                String root = getFilesDir().getAbsolutePath();
                String file = "camera-feature.xml";
                String dir = "/system/cameradata/";
                exec("cp "+root+sl+file+s+dir, 1);
                ipush("CFT: restored xml from "+root);
                refresh();
            }
        }.start();
    }
    
    public void rstore_stock() {
        String root = getFilesDir().getAbsolutePath();
        String file = "camera-feature.xml";
        String s = " "; String dir = "/system/cameradata/";
        exec("cp "+root+"/backup/"+file+s+dir, 1);
        refresh();
    }
    
    public void applyTemp(boolean overwrite) {
        String which = "";
        if(overwrite == true) {
            which=" > ";
        } else if(overwrite == false) {
            which=" >> ";
        }
        String xml="/system/cameradata/camera-feature.xml";
        String root = getFilesDir().getAbsolutePath();
        String temp=root+"/.temp";
        exec("cat "+temp+which+xml,1);
        killCamera();
    }
    
    public void nukeFeature(String toNuke) {
        String xml="/system/cameradata/camera-feature.xml";
        String root = getFilesDir().getAbsolutePath();
        String temp=root+"/.temp";
        exec("cat "+xml+" | sed '/"+toNuke+"/d' > "+temp,1);
        applyTemp(true);
    }
    
    public void addFeature(String toAdd) {
        String root = getFilesDir().getAbsolutePath();
        String temp=root+"/.temp";
        exec("echo '"+toAdd+"' > "+temp,1);
        applyTemp(false);
    }
    
    public void tryAndRead() {
        String check = getFeature("FRONT_CAMERA_RECORDING_DEFAULT_RESOLUTION");
        if(check.isEmpty() || check.equals(null)) {
            ipush("ERROR: unable to read camera-feature.xml, please report this");
        }
    }
    
    public void fps(final boolean enable) {
        tryAndRead();
        String res = getCurrentResolution();
        String line = getFeature("MAP_"+res+" | grep BACK | grep -v FPS");
        if(enable == true) {
            ipush("CFT: writing a new line with resolution "+res+"_60FPS");
            String line60 = line.replace(res, res+"_60FPS");
            addFeature(line60);
        } else {
            ipush("CFT: removing line wih resolution "+res+"_60FPS");
            nukeFeature("_60FPS");
        }
    }
    
    // base #0 (make a void, and add it to blenk)
    public void blenk(final String toStart, final boolean mode) {
        enableSwitches(false);
        new CountDownTimer(700, 700) {
            @Override
            public void onTick(long p1) {
            }
            @Override
            public void onFinish() {
                enableSwitches(true);
                switch (toStart) {
                    case "fun":
                        fun(mode);
                        break;
                    case "fps":
                        fps(mode);
                        break;
                    case "port":
                        port(mode);
                        break;
                    case "rstore":
                        rstore();
                        break;
                    case "food":
                        food(mode);
                        break;
                    case "single":
                        single(mode);
                }
            }
        }.start();
    }
    
    public void fun(boolean enable) {
        tryAndRead();
        String method = "SHOOTING_MODE_FUN";
        String line= "<local name=\"SHOOTING_MODE_FUN\" back=\"FUN\" front=\"FUN\" enable=\"true\" more=\"false\" order=\"1\" />";
        if(enable == true) {
            ipush("CFT: writing a new line with method "+method);
            addFeature(line);
        } else {
            ipush("CFT: removing line wih method "+method);
            nukeFeature(method);
        }
    }
    
    public void port(boolean enable) {
        tryAndRead();
        String method = "SHOOTING_MODE_LIVE_FOCUS";
        String line = "<local name=\"SHOOTING_MODE_LIVE_FOCUS\" back=\"LIVE_FOCUS\" front=\"SELFIE_FOCUS\" enable=\"true\" more=\"false\" order=\"2\" info=\"6\"/>";
        if(enable == true) {
            ipush("CFT: writing a new line with method "+method);
            addFeature(line);
        } else {
            ipush("CFT: removing line wih method "+method);
            nukeFeature(method);
        }
    }
    
    public void food(final boolean enable) {
        tryAndRead();
        String method = "SHOOTING_MODE_FOOD";
        String line= "<local name=\"SHOOTING_MODE_FOOD\" back=\"FOOD\" enable=\"true\" more=\"true\" order=\"8\" info=\"2\"/>";
        if(enable == true) {
            ipush("CFT: writing a new line with method "+method);
            addFeature(line);
        } else {
            ipush("CFT: removing line wih method "+method);
            nukeFeature(method);
        }
    }

    public void single(boolean enable) {
        tryAndRead();
        String method = "SHOOTING_MODE_SINGLE_TAKE_PHOTO";
        String line = "<local name=\"SHOOTING_MODE_SINGLE_TAKE_PHOTO\" back=\"SINGLE_TAKE_PHOTO\" front=\"SINGLE_TAKE_PHOTO\" enable=\"true\" more=\"true\" order=\"6\" preview-size=\"1440x1080\" capture-size=\"3264x2448\" front-capture-size=\"2944x2208\" info=\"1\" big-info=\"true\"/>";
        if(enable == true) {
            ipush("CFT: writing a new line with method "+method);
            addFeature(line);
        } else {
            ipush("CFT: removing line wih method "+method);
            nukeFeature(method);
        }
    }
    
    public void safe() {
        final String root = getFilesDir().getAbsolutePath();
        final AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
            .setTitle("Restore stock xml")
            .setMessage("This will restore the camera-feature.xml backed up on first app launch\n\nPress OK to continue")
            .setCancelable(false)
            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ipush("CFT: restoring stock camera-feature.xml from "+root+"/backup");
                    rstore_stock();
                    enableSwitches(true);
                }
            })
            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ipush("CFT: no restore was done");
                    enableSwitches(true);
                }
            })
            .create();
        dialog.show();
    }
    
    // for switches
    public void killCamera() {
        exec("am force-stop com.sec.android.app.camera",1);
    }
    
    public boolean cameraIsRunning() {
        return exec("pidof com.sec.android.app.camera", 1) != "";
    }
    
    // base #1 (add switch to enableSwitches and refresh)
    public void refresh() {
        final Switch fps = findViewById(R.id.fps_switch);
        final Switch fun = findViewById(R.id.fun_switch);
        final Switch port = findViewById(R.id.port_switch);
        final Switch food = findViewById(R.id.food_switch);
        final Switch single = findViewById(R.id.single_switch);
        fps.setChecked(getFeature("_60FPS") != "");
        fun.setChecked(getFeature("SHOOTING_MODE_FUN") != "");
        port.setChecked(getFeature("SHOOTING_MODE_LIVE_FOCUS") != "");
        food.setChecked(getFeature("SHOOTING_MODE_FOOD") != "");
        single.setChecked(getFeature("SHOOTING_MODE_SINGLE_TAKE_PHOTO") != "");
    }
    
    public void enableSwitches(boolean enable) {
        final Switch fps = findViewById(R.id.fps_switch);
        final Switch fun = findViewById(R.id.fun_switch);
        final Switch port = findViewById(R.id.port_switch);
        final Switch food = findViewById(R.id.food_switch);
        final Switch single = findViewById(R.id.single_switch);
        fps.setEnabled(enable);
        fun.setEnabled(enable);
        port.setEnabled(enable);
        food.setEnabled(enable);
        single.setEnabled(enable);
    }
    
    CountDownTimer cdown = new CountDownTimer(1500, 1500) {
        @Override
        public void onTick(long p1) {
        }
        @Override
        public void onFinish() {
            enableSwitches(true);
        }
    };
    
    public void blink() {
        enableSwitches(false);
        cdown.start();
    }
    
    public String getCurrentResolution() {
        String line = getFeature("BACK_CAMERA_RECORDING_DEFAULT_RESOLUTION | grep -o [0-9.x]");
        String res = ""; line = line.replace("\n", ""); res = line.replace("x", "X");
        return res;
    }
    
    public void fishKill() {
        Button kill = findViewById(R.id.kill); kill.setEnabled(cameraIsRunning());
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // on start
        refresh();
        
        // environment variables
        String root = getFilesDir().getAbsolutePath();
        String file = "camera-feature.xml";
        String s = " "; String sep = " | ";
        
        // one time backup
        String check = exec("ls "+root+"/backup"+sep+" grep "+file, 1);
        if(check.isEmpty() || check == null) {
        exec("mkdir "+root+"/backup", 1);
        exec("cp "+"/system/cameradata/"+file+s+root+"/backup", 1);
        ipush("CFT: revert backup was made in "+root+"/backup");
        }
        
        // elements
        Button backup = findViewById(R.id.backup);
        final Button restore = findViewById(R.id.restore);
        Button restore_stock = findViewById(R.id.restore_stock);
        Button launch = findViewById(R.id.launch);
        Button kill = findViewById(R.id.kill); fishKill();
        Button clr = findViewById(R.id.clr);
        // base #2 (define switch)
        final EditText logbox = findViewById(R.id.logbox);
        final Switch fps_switch = findViewById(R.id.fps_switch);
        final Switch port_switch = findViewById(R.id.port_switch);
        final Switch fun_switch = findViewById(R.id.fun_switch);
        final Switch food_switch = findViewById(R.id.food_switch);
        final Switch single_switch = findViewById(R.id.single_switch);
        
        // check if backed up before
        String temp = exec("ls "+root+sep+"grep "+file, 1);
        if(temp.equals("")) {
            ipush("CFT: no backup found");
            restore.setEnabled(false);
        } else {
            ipush("CFT: found backup in "+root);
            TextView location = findViewById(R.id.location);
            location.setText("Currently backed up in app/files");
        }
        
        // onClickListeners
        View.OnClickListener ear = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.backup:
                        bqp();
                        restore.setEnabled(true);
                        break;
                    case R.id.restore:
                        blenk("rstore", true);
                        break;
                    case R.id.restore_stock:
                        enableSwitches(false);
                        safe();
                        break;
                    case R.id.launch:
                        exec("am start com.sec.android.app.camera", 1);
                        break;
                    case R.id.kill:
                        killCamera();
                        break;
                    case R.id.clr:
                        logbox.setText("");
                        break;
                    case R.id.fps_switch:
                        blenk("fps", fps_switch.isChecked());
                        break;
                    case R.id.port_switch:
                        blenk("port", port_switch.isChecked());
                        break;
                    case R.id.fun_switch:
                        blenk("fun", fun_switch.isChecked());
                        break;
                    case R.id.food_switch:
                        blenk("food", food_switch.isChecked());
                        break;
                    case R.id.single_switch:
                        blenk("single", single_switch.isChecked());
                        break;
                }
                fishKill();
            }
        };
        // base #3 (add switch as array member)
        Button[] btn = {backup, restore, restore_stock, launch, kill, clr, fps_switch, fun_switch, port_switch, single_switch, food_switch};
        for (Button b : btn) {
            b.setOnClickListener(ear);
        }
        
    }
}
