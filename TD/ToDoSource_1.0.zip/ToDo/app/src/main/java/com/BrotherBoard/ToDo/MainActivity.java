package com.BrotherBoard.ToDo;
 
import android.animation.LayoutTransition;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends Activity { 

    String root = "/data/data/com.BrotherBoard.ToDo/files/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getVar("isLight").isEmpty()) {
            storeVar("isLight", "1");
        }
        setTheme(getVar("isLight").equals("1") ? android.R.style.Theme_DeviceDefault_Light_NoActionBar : android.R.style.Theme_DeviceDefault_NoActionBar);
        setContentView(R.layout.activity_main);
        Button remove = findViewById(R.id.remove);
        Button settings = findViewById(R.id.settings);
        
        settings.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View p1) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    final List items = Arrays.asList("Switch theme", "Check all", "Uncheck all", "Refresh layout");
                    builder.setTitle("More");
                    ListView listView = new ListView(MainActivity.this);
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, items);
                    listView.setAdapter(adapter);
                    builder.setView(listView);
                    final AlertDialog dialog = builder.create();
                    dialog.show();
                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4) {
                                switch (p3) {
                                    case 0:
                                        Boolean isLight = getVar("isLight").equals("1");
                                        storeVar("isLight", isLight ? "0" : "1");
                                        recreate();
                                        break;
                                    case 1:
                                        all(true);
                                        break;
                                    case 2:
                                        all(false);
                                        break;
                                    case 3:
                                        fresh();
                                }
                                dialog.dismiss();
                            } 
                        });
                }
            });
        remove.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {
                rem();
            }
        });
        fresh();
        enableAdd();
    }
    
    public void enableAdd() {
        Button add = findViewById(R.id.add);
        final OnCheckedChangeListener check_ear = new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton p1, boolean p2) {
                check(p1.getText() + "‖", p2);
            }
        };
        
        final LinearLayout layout = findViewById(R.id.layout);
        
        final EditText check_text = new EditText(this);
        check_text.setHint("Check title");
        
        LinearLayout UOD = new LinearLayout(this);
        UOD.setOrientation(1);
        
        final EditText Sp_txt = new EditText(this);
        Sp_txt.setInputType(InputType.TYPE_CLASS_NUMBER);
        Sp_txt.setWidth(80);
        Sp_txt.setHint("1");
        Sp_txt.setEnabled(false);
        
        final TextView nah2 = new TextView(this);
        nah2.setTextColor(Color.RED);
        nah2.setVisibility(View.INVISIBLE);
        nah2.setText("Please define where to add the check");
        
        final RadioButton Up = new RadioButton(this);
        final RadioButton Sp = new RadioButton(this);
        final RadioButton Down = new RadioButton(this);
        
        Up.setText("Append to beginning");
        Up.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View p1) {
                    Up.setChecked(true);
                    Down.setChecked(false);
                    Sp.setChecked(false);
                    Sp_txt.setEnabled(false);
                    Sp_txt.setText("1");
                    nah2.setVisibility(View.INVISIBLE);
                }
            });
        Sp.setText("Append to index: ");
        Sp.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View p1) {
                    Sp.setChecked(true);
                    Sp_txt.setEnabled(true);
                    Down.setChecked(false);
                    Up.setChecked(false);
                    Sp_txt.setText("1");
                    nah2.setVisibility(View.INVISIBLE);
                }
            });
        Down.setText("Append to end");
        Down.setChecked(true);
        Down.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View p1) {
                    Down.setChecked(true);
                    Sp.setChecked(false);
                    Up.setChecked(false);
                    Sp_txt.setEnabled(false);
                    Sp_txt.setText("1");
                    nah2.setVisibility(View.INVISIBLE);
                }
            });
            
        LinearLayout Sp_lay = new LinearLayout(this);
        Sp_lay.addView(Sp);
        Sp_lay.addView(Sp_txt);
        
        UOD.addView(Up);
        UOD.addView(Down);
        UOD.addView(Sp_lay);
        
        final TextView nah = new TextView(this);
        nah.setTextColor(Color.RED);
        nah.setVisibility(View.INVISIBLE);
        nah.setText("A check with the same name already exists!");
        
        LinearLayout new_check = new LinearLayout(this);
        
        new_check.setOrientation(1);
        new_check.addView(check_text);
        new_check.addView(nah);
        new_check.addView(UOD);
        new_check.addView(nah2);
        
        final AlertDialog.Builder add_dialog = new AlertDialog.Builder(this);
        add_dialog.setCancelable(false);
        add_dialog.setTitle("Add a check");
        add_dialog.setView(new_check);
        add_dialog.setPositiveButton("Add", new DialogInterface.OnClickListener() {
                @Override  
                public void onClick(DialogInterface p1, int p2) {
                    CheckBox toAdd = new CheckBox(MainActivity.this);
                    String txt = "‎"+check_text.getText().toString().replaceAll("‖", "|");
                    toAdd.setText(txt);
                    check_text.setText("");
                    
                    LayoutTransition transition = new LayoutTransition();
                    transition.enableTransitionType(LayoutTransition.CHANGING);
                    ((LinearLayout)findViewById(R.id.layout)).setLayoutTransition(transition);

                    if (Up.isChecked()) {
                        layout.addView(toAdd, 0);
                        appendAt("check_list.txt", 0, txt + "‖" + false);
                    } else if (Down.isChecked()) {
                        layout.addView(toAdd);
                        append("check_list.txt", txt + "‖" + false);
                    } else {
                        int index = Integer.parseInt(Sp_txt.getText().toString()) - 1;
                        layout.addView(toAdd, index);
                        appendAt("check_list.txt", index, txt + "‖" + false); 
                    }
                    toAdd.setOnCheckedChangeListener(check_ear);
                }
            });
        add_dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface p1, int p2) {
                }
            });
        final AlertDialog dial = add_dialog.create();
        TextWatcher eye2 = new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {
                }
                @Override
                public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {
                    int num = (Integer.parseInt("0"+p1) - 1);
                    if (num > layout.getChildCount() || num < 0 || check_text.getText().toString().isEmpty()) {
                        dial.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                    } else {
                        dial.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                    }
                }
                @Override
                public void afterTextChanged(Editable p1) {
                }
            };
        Sp_txt.addTextChangedListener(eye2);
        TextWatcher eye = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {
            }
            @Override
            public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {
                Button btn = dial.getButton(AlertDialog.BUTTON_POSITIVE);
                if (isThere(p1.toString())) {
                    nah.setVisibility(View.VISIBLE);
                    btn.setEnabled(false);
                } else {
                    nah.setVisibility(View.INVISIBLE);
                    btn.setEnabled(!p1.toString().isEmpty());
                }
            }
            @Override
            public void afterTextChanged(Editable p1) {
            }
        };
        check_text.addTextChangedListener(eye);
        add.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View p1) {
                    dial.show();
                    dial.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                }
            });
    }
    
    public void all(boolean check) {
        String old = read("check_list.txt");
        String[] arr = old.split("\n");
        int n = 0;
        for (String chk : arr) {
            arr[n] = chk.replace("‖"+!check, "‖"+check);
            n++;
        }
        String oke = "".join("\n", arr);
        write("check_list.txt", oke);
        for (View v : ((LinearLayout)findViewById(R.id.layout)).getTouchables()) {
            ((CheckBox)v).setChecked(check);
        }
    }
    
    public void rem() {
        final LinearLayout rem_lay = new LinearLayout(this);
        rem_lay.setOrientation(1);
        String[] checks = read("check_list.txt").split("\n");
        for (String check : checks) {
            if (!check.isEmpty()) {
                String[] elems = check.split("\\‖");
                CheckBox box = new CheckBox(this);
                box.setText(elems[0]);
                rem_lay.addView(box);
            }
        }
        AlertDialog.Builder rem_dial = new AlertDialog.Builder(this);
        rem_dial.setTitle("Remove a check");
        rem_dial.setView(rem_lay);
        rem_dial.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface p1, int p2) {
                }
        });
        rem_dial.setPositiveButton("Remove", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface p1, int p2) {
                    ArrayList<View> boxes = rem_lay.getTouchables();
                    for (View checkbox : boxes) {
                        if (((CheckBox) checkbox).isChecked()) {
                            nuke(((CheckBox) checkbox).getText()+"");
                        }
                    }
                }
        });
        rem_dial.show();
    }
    
    public void toast(String toToast) {
        Toast.makeText(MainActivity.this, toToast, Toast.LENGTH_LONG).show();
    }
    
    public void fresh() {
        final OnCheckedChangeListener check_ear = new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton p1, boolean p2) {
                check(p1.getText() + "‖", p2);
            }
        };
        final LinearLayout layout = findViewById(R.id.layout);
        layout.removeAllViews();
        String[] checks = read("check_list.txt").split("\n");
        for (String check : checks) {
            if (!check.isEmpty()) {
                String[] elems = check.split("\\‖");
                CheckBox box = new CheckBox(this);
                box.setText(elems[0]);
                box.setChecked(elems[1].startsWith("t"));
                box.setOnCheckedChangeListener(check_ear);
                layout.addView(box);
            }
        }
    }
    
    public String read(String filename) {
        String found = "";
        try {
            BufferedReader reader = new BufferedReader(new FileReader(root + filename));
            String line;
            try {
                while ((line = reader.readLine()) != null) {
                    found = found + (found.isEmpty() ? "" : "\n") + line;
                }
            } catch (IOException e) {
                write("logs.txt", e+"");
            }
        } catch (FileNotFoundException e) {
            write("logs.txt", e+"");
        }
        return found;
    }
    
    public void check(String wildcard, Boolean isChecked) {
        String old = read("check_list.txt");
        String[] arr = old.split("\n");
        int n = 0;
        for (String check : arr) {
            if (check.startsWith(wildcard)) {
                arr[n] = check.replace(!isChecked+"", isChecked+"");
                break;
            }
            n++;
        }
        String oke = "".join("\n", arr);
        write("check_list.txt", oke);
    }
    
    public boolean isThere(String line) {
        String old = read("check_list.txt");
        String[] arr = old.split("\n");
        for (String check : arr) {
            if (check.startsWith("‎"+line+"‖")) {
                return true;
            }
        }
        return false;
    }
    
    public void nuke(String wildcard) {
        String old = read("check_list.txt");
        String[] arr = old.split("\n");
        int n = 0;
        for (String check : arr) {
            if (check.startsWith(wildcard+"‖")) {
                arr[n] = "";
            }
            n++;
        }
        String oke = "".join("\n", arr);
        write("check_list.txt", oke);
        LayoutTransition transition = new LayoutTransition();
        transition.enableTransitionType(LayoutTransition.CHANGING); // Enable CHANGE_APPEARING and CHANGE_DISAPPEARING
        ((LinearLayout)findViewById(R.id.layout)).setLayoutTransition(transition);
        for (final View v : ((LinearLayout)findViewById(R.id.layout)).getTouchables()) {
            if (((CheckBox)v).getText().toString().contains(wildcard)) {
                ((LinearLayout)findViewById(R.id.layout)).removeView(v);
            }
        }
    }
    
    public void write(String filename, String toWrite) {
        try {
            try(FileWriter writer = new FileWriter(root + filename, false)) {
            writer.write(toWrite+"\n");}
        } catch (IOException e) {
            write("logs.txt", e+"");
        }
    }
    
    public void appendAt(String filename, int index, String toAppend) {
        Path path = Paths.get(root + filename);
        try {
            List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
            lines.add(index, toAppend);
            Files.write(path, lines, StandardCharsets.UTF_8);
        } catch (IOException e) {}
    }
    
    public void append(String filename, String toAppend) {
        try {
            try(FileWriter writer = new FileWriter(root + filename, true)) {
                writer.write(toAppend+"\n");}
        } catch (IOException e) {
            write("logs.txt", e+"");
        }
    }
    
    public void storeVar(String varName, String varValue) {
        SharedPreferences VARS = getSharedPreferences("TODO_VARS", MODE_PRIVATE);
        SharedPreferences.Editor editShare = VARS.edit();
        editShare.putString(varName, varValue);
        editShare.apply();
    }

    public void nukeVar(String varName) {
        SharedPreferences VARS = getSharedPreferences("TODO_VARS", MODE_PRIVATE);
        SharedPreferences.Editor editShare = VARS.edit();
        editShare.putString(varName, "");
        editShare.apply();
    }

    public String getVar(String varName) {
        SharedPreferences VARS = getSharedPreferences("TODO_VARS", MODE_PRIVATE);
        return VARS.getString(varName, varName);
    }
}
