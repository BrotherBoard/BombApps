package com.BrotherBoard.DRC;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.lang.Process;
import java.math.*;
import android.transition.*;
import android.widget.CompoundButton.*;
import android.text.*;
import java.util.*;
import java.sql.Struct;
import java.util.function.Function;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.view.Display.Mode;


public class MainActivity extends Activity 
{
    public void ipush(String toPush) {
        TextView tips = findViewById(R.id.tips);
        tips.setVisibility(View.VISIBLE);
        final EditText logbox = findViewById(R.id.logs);
        String oldText=logbox.getText().toString();
        if(oldText.isEmpty()) {
            logbox.setText(toPush);
        } else {
            logbox.setText(oldText+"\n"+toPush);
            
        }
        tips.setText(toPush);
    }
    
    public String check(){
        CheckBox log_info = findViewById(R.id.log_info);
        String allow="";
        if(log_info.isChecked()) {
            allow="1";
        } else {
            allow="0";
        }
        return allow;
    }
    
    public String info(String mode) {
        TextView tips = findViewById(R.id.tips);
        String xy_og="";
        String xy_new="";
        String x_og="";
        String y_og="";
        String okey="";
        String d_og=exec("su -c wm density | sed 's/Physical density: //' | grep [1-9]");
        String d_new=exec("su -c wm density | grep Override | sed 's/Override density: //' | grep [1-9]");
        xy_new=exec("su -c wm size | grep Override | sed 's/Override size: //'");
        xy_og=exec("su -c wm size | sed 's/Physical size: //'");
        if(mode.equals("0")){
        if(check().equals("1")) {
        ipush("Original resolution: "+xy_og+"\nOriginal density: "+d_og);
            tips.setText("Original resolution: "+xy_og+" & Original density: "+d_og);
        if(xy_new.equals("")) {} else {
            ipush("Current resolution: "+xy_new);
        }}}
        if(d_new.equals("")) {} else {
            ipush("Current density: "+d_new);
        }
        if(mode.contains("1")) {
            String xy_og_arr[]=xy_og.split("x");
            x_og=xy_og_arr[0];
            y_og=xy_og_arr[1];
        }
        if(mode.contains("x")) {
            okey=x_og;
        } else if(mode.contains("y")) {
            okey=y_og;
        } else if(mode.contains("d_og")) {
            okey=d_og;
        } else if(mode.contains("d_new")) {
            okey=d_new;
        }
        return okey;
    }
    
    public String exec(String cmd) {
        CheckBox log_cmds = findViewById(R.id.log_cmds);
        CheckBox log_outs = findViewById(R.id.log_outs);
        String exec_out="";
        String exec_out2="";
        try {
        Process process = Runtime.getRuntime().exec(cmd);
        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        exec_out=reader.readLine();
        exec_out2=exec_out+"a";
        if(log_cmds.isChecked()) {
        ipush("~#"+cmd); }
        if(log_outs.isChecked()) {
        ipush(exec_out); }
        } catch (IOException e) {}
        if (exec_out2.equals("nulla")) {
            return "";
        } else {
        return exec_out;
    }}
    
    public String calc(String toCalc, String mode) {
        CheckBox math = findViewById(R.id.log_maths); math.setChecked(true);
        String result="";
        int toSendi = 0;
        String X=info("1x");
        String Y=info("1y");
        int Xi = Integer.parseInt(X);
        int Yi = Integer.parseInt(Y);
        int toCalci = Integer.parseInt(toCalc);
        int d_ogi = Integer.parseInt(info("d_og"));
        if(mode.equals("X")) {
            // Xi     : Yi
            // toCalci: toSendi
            toSendi = ((Yi * toCalci) / Xi);
            if (math.isChecked()) {
                ipush("Need Y");
                ipush("Y="+Yi+"*"+toCalci+"/"+Xi);
                ipush("Y="+toSendi);
            }
        } else if(mode.equals("Y")) {
            // Xi     : Yi
            // toSendi: toCalci
            toSendi = ((Xi * toCalci) / Yi);
            
            if (math.isChecked()) {
                ipush("Need X");
                ipush("X=("+Xi+"*"+toCalci+")/"+Yi);
                ipush("X="+toSendi);
            }
        } else if(mode.equals("D")) {
            // Xi     : d_ogi
            // toCalci: toSendi
            toSendi = ((d_ogi * toCalci) / Xi);
            if (math.isChecked()) {
                ipush("Need D");
                ipush("D=("+d_ogi+"*"+toCalci+")/"+Xi);
                ipush("D="+toSendi);
            }
        }
        result=toSendi+"";
        return result;
    }
    public void applie() {
        final EditText X = findViewById(R.id.X);
        String xres = X.getText().toString();
        final EditText Y = findViewById(R.id.Y);
        final RadioButton Pr = findViewById(R.id.Pr);
        String yres = Y.getText().toString();
        exec("su -c wm size " + xres + "x" + yres);
        String dres = calc(X.getText().toString(), "D");
        exec("su -c wm density " + dres);
        Pr.setChecked(true);
    }
    
    public void failsafe() {
        final TextView bruh = findViewById(R.id.bruh);
        bruh.setText("0");
        final AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
            .setTitle("Resolution Changed")
            .setMessage("Your screen resolution was changed, press OK to continue")
            .setPositiveButton("Revert", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // Do something to reset the display settings
                    ipush("Failsafe: user reverted, resetted settings for display 0");
                    exec("su -c wm size reset");
                    exec("su -c wm density reset");
                }
            })
            .setNegativeButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ipush("Failsafe: user confirmed working");
                    bruh.setText("1");
                }
            })
            .create();
        dialog.show();
        
        CountDownTimer cdown = new CountDownTimer(5000, 1000) {
            int down = 5;
            @Override
            public void onTick(long p1) {
                dialog.setMessage("Your screen resolution was changed, press OK to continue.\n\nReverting in "+down+" seconds.");
                --down;
            }
            @Override
            public void onFinish() {
                String txt = bruh.getText().toString();
                if(txt.equals("1")) {
                // confirmed working, do nothing about it
                } else if(txt.equals("0")){
                // timeout, user is in trouble
                    dialog.dismiss();
                    exec("su -c wm size reset");
                    exec("su -c wm density reset");
                    ipush("Failsafe: timeout, resetting settings for display 0");
                }
            }
        };
        cdown.start();
    }
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        CheckBox log_info = findViewById(R.id.log_info); log_info.setChecked(true);
        CheckBox log_maths = findViewById(R.id.log_maths); log_maths.setChecked(true);
        //CheckBox log_cmd = findViewById(R.id.log_cmds); log_cmd.setChecked(true);
        final EditText X = findViewById(R.id.X);
        
        final EditText Y = findViewById(R.id.Y);
        final EditText logbox = findViewById(R.id.logs);
        final RadioButton Xr = findViewById(R.id.Xr);
        final RadioButton Yr = findViewById(R.id.Yr);
        final RadioButton XYr = findViewById(R.id.XYr);
        final RadioButton Pr = findViewById(R.id.Pr);
        final Button list = findViewById(R.id.list);
        Button reset = findViewById(R.id.reset);
        list.setEnabled(false);
        final Button clear = findViewById(R.id.clr);
        final Button apply = findViewById(R.id.ok);
        Button print = findViewById(R.id.print);
        final Button yeah = findViewById(R.id.yeah); yeah.setEnabled(false);
        apply.setEnabled(false);
        X.setEnabled(false);
        Y.setEnabled(false);
        
        X.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {
                }
                @Override
                public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {
                    
                    if(X.getText().toString().equals("0")) {
                        apply.setEnabled(false);
                        yeah.setEnabled(false);
                    } else if(X.getText().toString().isEmpty()) {
                        apply.setEnabled(false);
                        yeah.setEnabled(false);
                    } else {
                        if(Y.getText().toString().equals(0)){
                            yeah.setEnabled(false);
                        } else if(Y.getText().toString().isEmpty()) {
                            yeah.setEnabled(false);
                        } else {
                            if(Integer.parseInt(X.getText().toString()) < 200){
                                yeah.setEnabled(false);
                                
                                } else if (Integer.parseInt(X.getText().toString()) > 200){
                                    yeah.setEnabled(false);
                                    
                                } else {
                            yeah.setEnabled(true);
                            
                            }
                        }
                        if(Xr.isChecked()) {
                            apply.setEnabled(true);
                        }
                    }
                }
                @Override
                public void afterTextChanged(Editable p1) 
        {}});
        
        yeah.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                failsafe();
                            }
                        }, 5000);
                    applie();
                }
            });
            
        Y.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {
                }
                @Override
                public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {
                    if(Y.getText().toString().equals("0")) {
                        apply.setEnabled(false);
                        yeah.setEnabled(false);
                    } else if(Y.getText().toString().isEmpty()) {
                        apply.setEnabled(false);
                        yeah.setEnabled(false);
                    } else {
                        if(X.getText().toString().equals(0)){
                            yeah.setEnabled(false);
                        } else if(X.getText().toString().isEmpty()) {
                            yeah.setEnabled(false);
                        } else {
                            yeah.setEnabled(true);
                        }
                        if(Yr.isChecked()) {
                            apply.setEnabled(true);
                        }
                    }
                }
                @Override
                public void afterTextChanged(Editable p1) {
                }
            });
        
        reset.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View p1) {
                    AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Reset")
                        .setMessage("This will reset your display resolution, sure you want to proceed?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // Do something to reset the display settings
                                ipush("Resetting settings for display 0");
                                exec("su -c wm size reset");
                                exec("su -c wm density reset");
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ipush("Reset: canceled");
                            }
                        })
                        .create();

                    // Show the dialog
                    dialog.show();
                }
            });
        apply.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View p1) {
                    if(Xr.isChecked()) {
                        // I have X, Calculate Y
                        String X_inp = X.getText().toString();
                        String Y_inp=calc(X_inp, "X");
                        Y.setText(Y_inp);
                    } else  if(Yr.isChecked()) {
                        // I have Y, Calculate X
                        String Y_inp = Y.getText().toString();
                        String X_inp=calc(Y_inp, "Y");
                        X.setText(X_inp);
                    }
                }
        });
        clear.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View p1) {
                    logbox.setText("");
                }
        });
        print.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View p1) {
                    info("0");
                }
            });
        logbox.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {
                }
                @Override
                public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {
                    String current = logbox.getText().toString();
                    if(current.isEmpty()) {
                        clear.setEnabled(false);
                    } else {
                        clear.setEnabled(true);
                    }
                }
                @Override
                public void afterTextChanged(Editable p1) {
                }
        });
        
        Xr.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {
                X.setEnabled(true);
                Y.setEnabled(false);
                Y.setText("");
                X.setText("");
                ipush("Selected X (will calculate Y)");
                list.setEnabled(false);
                yeah.setEnabled(false);
            }
        });
        Yr.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View p1) {
                    Y.setEnabled(true);
                    X.setEnabled(false);
                    X.setText("");
                    Y.setText("");
                    ipush("Selected Y (will calculate X)");
                    list.setEnabled(false);
                    yeah.setEnabled(false);
                }
            });
        XYr.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View p1) {
                    X.setEnabled(true);
                    Y.setEnabled(true);
                    ipush("Selected X and Y");
                    list.setEnabled(false);
                    //apply.setEnabled(true);
                    yeah.setEnabled(false);
                }
            });
        
        Pr.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View p1) {
                    X.setEnabled(false);
                    X.setText("");
                    Y.setEnabled(false);
                    Y.setText("");
                    ipush("Presets loaded");
                    list.setEnabled(true);
                }
            });
            
        list.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                final List items = Arrays.asList("4240p", "2160p", "1560p", "1080p", "720p", "480p", "360p", "280p");
                builder.setTitle("Presets");
                ListView listView = new ListView(MainActivity.this);
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, items);
                listView.setAdapter(adapter);
                builder.setView(listView);
                final AlertDialog dialog = builder.create();
                dialog.show();
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4) {
                                    String lel = (String)items.get(p3);
                                    ipush("Selected preset "+lel);
                                    //int leli = Integer.parseInt(lel);
                                    //if (leli > basei){
                                        //ipush("Passive warning: selected preset is wider than target device");
                                    //}
                                    lel=lel.substring(0, lel.length() - 1);
                                    X.setText(lel);
                                    String X_inp = X.getText().toString();
                                    //int X_inpi = Integer.parseInt(X_inp);
                                    String Y_inp=calc(X_inp, "X");
                                    Y.setText(Y_inp);
                                    ipush("Set Y: "+Y_inp);
                                    dialog.dismiss();
                                } 
                        });
                    }
            });
    }
}
