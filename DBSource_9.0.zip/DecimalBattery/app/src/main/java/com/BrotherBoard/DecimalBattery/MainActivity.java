package com.BrotherBoard.DecimalBattery;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;

import java.lang.Process;
import java.math.*;
import android.transition.*;
import android.widget.CompoundButton.*;
import android.text.*;
import java.util.*;
import java.sql.Struct;
import java.util.function.Function;

public class MainActivity extends Activity 
{
    private Handler hand = new Handler(Looper.getMainLooper());

    
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		// Switch autoswitch = findViewById(R.id.switch1);
		
		Button update = findViewById(R.id.updatebtn);
		chk();
        AD();
        iclear();
        ireset();
        hundred();
        listener();
		update.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View p1)
				{
					lmfao();
					return;
				}
			});}
		
		//private void auto() {
			
		//	lmfao();
		//}
		
        protected void AD() {
            CheckBox Advanced = findViewById(R.id.AD_ID);
            final TextView HELP_4 = findViewById(R.id.HELP_ID4);
            final TextView textView = findViewById(R.id.textout);
            Advanced.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, final boolean isChecked) {
                        if(isChecked) {
                            HELP_4.setText(("on"));
                            textView.setVisibility(View.VISIBLE);
                        } else {
                            HELP_4.setText(("off"));
                            textView.setVisibility(View.INVISIBLE);
                        }}
        });
        }
        
		protected void chk() {
			final Switch updt = findViewById(R.id.switch1);
			updt.setEnabled(false);
			final EditText waittxt = findViewById(R.id.waitbox);
			
			TextWatcher textWatcher = new TextWatcher() {

				@Override
				public void afterTextChanged(Editable p1)
				{
					// TODO: Implement this method
				}

				@Override
				public void beforeTextChanged(CharSequence s, int start, int count, int after) {
					updt.setEnabled(false);
				}

				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {
					// Do something ile the text is being changed.
					String waitst=waittxt.getEditableText().toString();
					if (waitst.isEmpty()) {
						updt.setEnabled(false);
					} else if (waitst.startsWith("0")) {
						updt.setEnabled(false);
					} else {
						updt.setEnabled(true);
                    }
				}
			};

            
			waittxt.addTextChangedListener(textWatcher);
            
			//op();
            
			updt.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

					@Override
					public void onCheckedChanged(CompoundButton buttonView, final boolean isChecked) {
                        
                        TextView HELP_3 = findViewById(R.id.HELP_ID3);
                        
						if (isChecked) {
                            ipush("AutoUpdate: ON");
                            HELP_3.setText("on");
                            ProgressBar anime = findViewById(R.id.anim);
                            anime.setVisibility((View.VISIBLE));
                            String waitst = waittxt.getEditableText().toString();
                            int waitint = Integer.parseInt(waitst);
                            int waitint2 = waitint * 1000;
                            
                            bsod(waitint2);
                            
                            
						} else {
                            ProgressBar anime = findViewById(R.id.anim);
                            ipush("AutoUpdate: OFF");
                            HELP_3.setText("off");
                            anime.setVisibility((View.INVISIBLE));
                            
                        }//if and while
					}
			});
		}
		
		//public void op() {
		//	final EditText waittxt = findViewById(R.id.waitbox);
		//	final Switch updt = findViewById(R.id.switch1);
		//	final String waitst=waittxt.getEditableText().toString();
		//	if (waitst != null) {
		//		updt.setEnabled(false);
		//	} else {
		//		updt.setEnabled(true);
		//	}
		//}
		
        protected void hundred() {
            Button mybatt = findViewById(R.id.mybatt100);
            mybatt.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View p1) {
                        BatteryManager batteryManager = (BatteryManager) getSystemService(BATTERY_SERVICE);
                        int blvl = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                        try {
                            Process process = Runtime.getRuntime().exec("su -c cat /sys/class/power_supply/battery/charge_counter");
                            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                            String var = reader.readLine();
                            reader.close();
                            
                            int var2 = Integer.parseInt(var);
                            int variable = var2 / 100;
                            if(blvl == 100) {
                                ipush("NICE, YOUR DIVISOR IS: "+variable);
                            } else {
                                ipush("liar, your battery is: "+blvl);
                            }
                        } catch (IOException e) {}
                        }
                    });
        }
        
    protected void doall(int num) {
        final Button todisable1 = findViewById(R.id.mybatt100);
        final Button todisable2 = findViewById(R.id.clearbtn_id);
        final Button todisable3 = findViewById(R.id.LISTEN_ID);
        final Button todisable4 = findViewById(R.id.clearall);
        final Button todisable5 = findViewById(R.id.updatebtn);
        final Switch todisable6 = findViewById(R.id.switch1);
        final EditText todisable7 = findViewById(R.id.custom);
        if (num == 1) {
        todisable1.setEnabled(false);
        todisable2.setEnabled(false);
        todisable3.setEnabled(false);
        todisable4.setEnabled(false);
        todisable5.setEnabled(false);
        todisable6.setEnabled(false);
        todisable7.setEnabled(false);
        } else {
        todisable1.setEnabled(true);
        todisable2.setEnabled(true);
        todisable3.setEnabled(true);
        todisable4.setEnabled(true);
        todisable5.setEnabled(true);
        todisable6.setEnabled(true);
        todisable7.setEnabled(true);
        }
    }
        
    protected void listener() {
        final Button LISTEN = findViewById(R.id.LISTEN_ID);
        final EditText SECST = findViewById(R.id.waitbox);
        final Switch updt = findViewById(R.id.switch1);
        final TextView tipview = findViewById(R.id.tips);
        
        LISTEN.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View p1) {
                    
                    TextView HELP_1 = findViewById(R.id.HELP_ID1);
                    try {
                        Process process = Runtime.getRuntime().exec("su -c cat /sys/class/power_supply/battery/charge_counter");
                        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                        String var = reader.readLine();
                        reader.close();
                        HELP_1.setText(var);
                        //HELP_1.setVisibility(View.VISIBLE);
                        ipush("Capture: started, set: "+var+"\nwill compare changes each update");
                        LISTEN.setEnabled(false);
                        SECST.setText("2");
                        updt.setChecked(true);
                        doall(1);
                        tipview.setText("Inspecting counter\nwaiting for your battery to drop 0.1%\nthis shouldn't take long");

                        
                    } catch (IOException e) {}
                }
            });
    }
        
		public void ipush(String newtxt) {
			EditText logview = findViewById(R.id.melog);
			String bqp=logview.getEditableText().toString();
			logview.setText(bqp+"\n"+newtxt);
		}
		
		public void isleep(final int seconds) {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... voids) {
                    try {
                        Thread.sleep(seconds);
                        
                        

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    return null;
                }

                @Override
                protected void onPostExecute(Void aVoid) {
                    
                    // Do something pls i beg
                }
            }.execute();
		}
		
    public void bsod(final int seconds) {
        new AsyncTask<Void, Void, Void>() {
            @Override
            int secs = seconds;
            TextView HELP_2 = findViewById(R.id.HELP_ID2);
            TextView HELP_3 = findViewById(R.id.HELP_ID3);
            protected Void doInBackground(Void... voids) {
                try {
                    
                    Thread.sleep(seconds);
                    



                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                String TEXT3 = HELP_3.getText().toString();
                if(TEXT3.equals("on")) {
                HELP_2.setText(secs+"");
                String TEXT2 = HELP_2.getText().toString();
                
                lmfao();
                int TEXT_int = Integer.parseInt(TEXT2);
                
                bsod(TEXT_int);
                }
            }
        }.execute();
    }
        
        private void iclear() {
            final EditText logview = findViewById(R.id.melog);
            Button clearbtn = findViewById(R.id.clearbtn_id);
            clearbtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View p1)
                    {
                        logview.setText("Logs:");
                    }
                });}
        
        private void ireset() {
            Button clearall = findViewById(R.id.clearall);
            final EditText logbox = findViewById(R.id.logs);
            final EditText dvide = findViewById(R.id.custom);
            final EditText prcnt = findViewById(R.id.gg);
			final EditText logbox2 = findViewById(R.id.logs2);
            final TextView textView = findViewById(R.id.textout);
            final TextView textView2 = findViewById(R.id.decimal);
			final TextView textView3 = findViewById(R.id.lmao);
            clearall.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View p1)
                    {
                        logbox.setText("Ready");
                        logbox2.setText("Ready");
                        dvide.setText("");
                        prcnt.setText("");
                        textView.setText("");
                        textView2.setText("");
                        textView3.setText("");
                    }
                });
        }
                
		public void lmfao() {
			String var = ""; // assign string var
			TextView textView = findViewById(R.id.textout);
			TextView textView2 = findViewById(R.id.decimal);
			TextView textView3 = findViewById(R.id.lmao);
			TextView tipview = findViewById(R.id.tips);
			EditText logbox = findViewById(R.id.logs);
			EditText dvide = findViewById(R.id.custom);
			EditText prcnt = findViewById(R.id.gg);
			EditText logbox2 = findViewById(R.id.logs2);
            TextView HELP_1 = findViewById(R.id.HELP_ID1);
            String TEXT_1 = HELP_1.getText().toString();
            TextView HELP_2 = findViewById(R.id.HELP_ID2);
            String TEXT_2 = HELP_2.getText().toString();
            Button LISTEN = findViewById(R.id.LISTEN_ID);
            Switch updt = findViewById(R.id.switch1);
            
			try
			{
				// set dvide visible
				// updt.setVisibility(View.VISIBLE);
				prcnt.setVisibility(View.VISIBLE);
				dvide.setVisibility(View.VISIBLE);
				String ctext = dvide.getText().toString();
				String ctext2 = "";
				String dvideby = "";
				if (ctext != null && !ctext.isEmpty()) {
					ctext2 = "done"; // custom
					dvideby = ctext;
					} else { // default divisor
						ctext2 = "2000";
						ctext = "none";
						dvideby = ctext2;
				}
				
                String lel = tipview.getText().toString();
                if (lel.startsWith("Attempted")) {
                    tipview.setText("Check the percentage,\ndid it work?");
                }
                
                if (lel.startsWith("Check")) {
                    tipview.setText("");
                }
                
				// execute command and assign output to var
				Process process = Runtime.getRuntime().exec("su -c cat /sys/class/power_supply/battery/charge_counter");
				BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
				var = reader.readLine();
				reader.close();

				// execute command and assign output to var3
				Process process3 = Runtime.getRuntime().exec("su -c dumpsys battery | grep 'charge counter' | sed 's/charge counter: //'");
				BufferedReader reader3 = new BufferedReader(new InputStreamReader(process3.getInputStream()));
				String var3 = reader3.readLine();
				reader.close();

				// get battery level and assign to blevel
				BatteryManager batteryManager = (BatteryManager) getSystemService(BATTERY_SERVICE);
				int blvl = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
				String blevel = blvl+"";
				
				// make int variants of strings, export decimal number
				int varint = Integer.parseInt(var); // 548000
				int ctextint = Integer.parseInt(dvideby);
				int varint2 = varint / ctextint; // 274
				String sure = varint2 + ""; // same
				float float1 = Float.parseFloat(sure);
				float1 = float1 / 10;
                
				double opm1 = varint / (blvl - 0.1) / 10;
				double op0 = varint / (blvl + 0.0) / 10;
				double op1 = varint / (blvl + 0.1) / 10;
				double op2 = varint / (blvl + 0.2) / 10;
				double op3 = varint / (blvl + 0.3) / 10;
				double op4 = varint / (blvl + 0.4) / 10;
				double op5 = varint / (blvl + 0.5) / 10;
				double op6 = varint / (blvl + 0.6) / 10;
				double op7 = varint / (blvl + 0.7) / 10;
				double op8 = varint / (blvl + 0.8) / 10;
				double op9 = varint / (blvl + 0.9) / 10;
				double op10 = varint / (blvl + 1.0) / 10;
                
				// for first and last values
				int blvlp = blvl + 1;
				int blvlm = blvl - 1;

				textView.setText("counter:\n"+var+"\n\nratio:\n"+sure+"\n\ndebug:\n"+"20000\n"+blevel+"\n\n"+"attmpt:\n"+float1+"\n\n"+"matches:\n"+var3+"\n\n"+"Divisor:\n"+ctext2+"\n\n"+"Custom divisor:\n"+ctext+"\n\n"+"Wait interval: \n"+TEXT_2+"\n\n"+"Captured: \n"+TEXT_1);
				textView2.setText("");                                               
				textView3.setText("");
				prcnt.setText(float1+"%");
				logbox.setText("psble dvide:\n"+opm1+"\n"+op0+"\n"+op1+"\n"+op2+"\n"+op3+"\n"+op4+"\n"+op5+"\n"+op6+"\n"+op7+"\n"+op8+"\n"+op9+"\n"+op10);
				logbox2.setText("prcnt:\n"+blvlm+".9"+"\n"+blvl+".0"+"\n"+blvl+".1"+"\n"+blvl+".2"+"\n"+blvl+".3"+"\n"+blvl+".4"+"\n"+blvl+".5"+"\n"+blvl+".6"+"\n"+blvl+".7"+"\n"+blvl+".8"+"\n"+blvl+".9"+"\n"+blvlp+".0");
                ipush("DB: updated");
                if(TEXT_1.equals("none")) {
                    //pass
                } else {
                    if(TEXT_1.equals(var)) {
                        ipush("Capture: uchanged ("+var+")");
                    } else {
                        int TEXT_1_int = Integer.parseInt(TEXT_1);
                        int susvar = (varint - TEXT_1_int);
                        ipush("Capture: changed ("+TEXT_1+")\nCapture: detected change: "+susvar);
                        ipush("Capture: cleared");
                        HELP_1.setText("none");
                        LISTEN.setEnabled(true);
                        int susvar_abs = 6969;
                        if(susvar <= 0) {
                            susvar_abs = (susvar * -1);
                        } else {
                            susvar_abs = susvar;
                        }
                        ipush("DB: suspected divisor: "+susvar_abs);
                        String susvar_abs_st = susvar_abs+"";
                            dvide.setText(susvar_abs_st);
                            tipview.setText("Attempted value "+susvar_abs_st+"\nas custom divisor, please update");
                        updt.setChecked(false);
                        ipush("AutoUpdate: was interrupted by Capture");
                        doall(0);
                    }
                }
			}                              
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	}

