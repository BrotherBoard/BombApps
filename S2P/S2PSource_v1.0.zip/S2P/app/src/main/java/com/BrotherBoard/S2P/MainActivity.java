package com.BrotherBoard.S2P;

import android.animation.Animator;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.Nullable;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.Toast;
import com.BrotherBoard.S2P.MainActivity;
import com.BrotherBoard.S2P.R;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.UUID;
import android.view.Gravity;
import android.widget.AbsoluteLayout.LayoutParams;

public class MainActivity extends Activity {
    
    private static final int SAVE_IMAGE_REQUEST_CODE = 1001;
    
    private boolean doubleBackToExitPressedOnce = false;
    private LinearLayout box;
    private LinearLayout in;
    private LinearLayout dad;
    private ArrayList<Button> list;
    private Button clear;
    private Button shorten;
    private Button expand;
    private Button update;
    private Switch auto;
    private EditText seed;
    private int index = 0;
    private int[] codes;
    private String[] chars;
    private Button export;
    private int old = 0;
    private AlertDialog dial;
    private ValueAnimator RGB;
    private int bruh1;
    private Button bruh2;
    private int bruh3;
    private LinearLayout lay;
    private LinearLayout lay2;
    private Bitmap bomb;
    private Button copy;
    private Button paste;
    private Button delete;
    private Button cut;
    private LinearLayout.LayoutParams marg;
    private int clipboard;
    private String clipboard2;
    private boolean copying;
    
    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }
        this.doubleBackToExitPressedOnce = true;
        toast("Press back again to go bye bye");
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    doubleBackToExitPressedOnce=false;                       
                }
            }, 2000);
    }
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainVoid();
    }
    
    public void storeVar(String varName, String varValue) {
        SharedPreferences VARS = getSharedPreferences("S2P_VARS", MODE_PRIVATE);
        SharedPreferences.Editor editShare = VARS.edit();
        editShare.putString(varName, varValue);
        editShare.apply();
    }
    
    public void nukeVar(String varName) {
        SharedPreferences VARS = getSharedPreferences("S2P_VARS", MODE_PRIVATE);
        SharedPreferences.Editor editShare = VARS.edit();
        editShare.putString(varName, "");
        editShare.apply();
    }
    
    public String getVar(String varName) {
        SharedPreferences VARS = getSharedPreferences("S2P_VARS", MODE_PRIVATE);
        return VARS.getString(varName, varName);
    }
    
    public void toast(String toToast) {
        Toast.makeText(MainActivity.this, toToast, Toast.LENGTH_LONG).show();
    }
    
    public void mainVoid() {
        int dpi = getResources().getDisplayMetrics().densityDpi;
        if( dpi < 340 ) {
            setContentView(R.layout.activity_main);
        }
        // DEBUGGING START
        /*final String t = ((EditText)findViewById(R.id.logbox)).getText().toString();
        ((Button)findViewById(R.id.bomb)).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {
                ((EditText)findViewById(R.id.logbox)).setText(sum_up(t));
            }
        });*/
        // DEBUGGING END
        
        box = findViewById(R.id.box);
        seed = findViewById(R.id.seed);
        clear = findViewById(R.id.clear);
        expand = findViewById(R.id.expand);
        shorten = findViewById(R.id.shorten);
        export = findViewById(R.id.export);
        update = findViewById(R.id.update);
        auto = findViewById(R.id.auto);
        list = new ArrayList<Button>();
        RGB = ValueAnimator.ofObject(new ArgbEvaluator(),
                                     Color.RED, Color.MAGENTA, Color.BLUE, Color.CYAN, Color.GREEN, Color.RED);
        RGB.setDuration(1500);
        RGB.setRepeatCount(ValueAnimator.INFINITE);
        clipboard = 999;
        clipboard2 = ".";
        bruh3 = 0;
        copying = false;
        cut = new Button(this);
        cut.setText("Cut");
        copy = new Button(this);
        copy.setText("Copy");
        delete = new Button(this);
        delete.setText("Delete");
        paste = new Button(this);
        paste.setText("Paste");
        paste.setEnabled(false);
        marg = new LinearLayout.LayoutParams(150, 75);
        marg.setMargins(10, 10, 10, 10);
        
        OnClickListener tools = new OnClickListener() {
            @Override
            public void onClick(View p) {
                switch (((Button)p).getText()+"") {
                    case "Delete":
                        byIndex(Integer.parseInt(bruh2.getText()+""), ".");
                        bruh1 = Color.TRANSPARENT;
                        break;
                    case "Cut":
                        clipboard = bruh1;
                        bruh1 = Color.TRANSPARENT;
                        byIndex(Integer.parseInt(bruh2.getText()+""), ".");
                        break;
                    case "Paste":
                        bruh1 = clipboard;
                        byIndex(Integer.parseInt((bruh2).getText()+""), clipboard2);
                        break;
                    case "Copy":
                        clipboard = bruh1;
                        copying = true;
                        break;
                }
                dial.cancel();
            }
        };
        
        for (Button b : new Button[] {cut, copy, paste, delete}) {
            b.setLayoutParams(marg);
            b.setOnClickListener(tools);
        }
        
        lay2 = new LinearLayout(MainActivity.this);
        lay2.addView(copy);
        lay2.addView(paste);
        lay2.addView(cut);
        lay2.addView(delete);
        lay2.setPadding(15, 15, 15, 15);
        lay2.setGravity(Gravity.CENTER);
        
        lay = new LinearLayout(MainActivity.this);
        lay.setOrientation(1);
        dad = new LinearLayout(MainActivity.this);
        dad.setOrientation(1);
        dad.addView(lay2);
        
        ScrollView scroll = new ScrollView(MainActivity.this);
        scroll.addView(lay);
        dad.setPadding(15, 15, 15, 15);
        dad.addView(scroll);
        
        expand.setEnabled(false);
        shorten.setEnabled(false);
        update.setEnabled(false);
        auto.setChecked(true);
        
        // colors
        chars = "0123456789AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz .".split("");
        int len = chars.length;
        codes = new int[len];
        float jump = 350f / (len - 6);
        for (int i = 0; i < len; i++) {
            float hue = 0;
            float sat = 0;
            float bri = 1;

            if (i == 0) {}
            else if (i == 1) bri = 0.75f;
            else if (i == 2) bri = 0.50f;
            else if (i == 3) bri = 0.25f;
            else if (i == 4) bri = 0.12f;
            else if (i == 5) bri = 0;
            else if (i == len - 1) {
                codes[i] = Color.TRANSPARENT;
                continue;
            }
            else {
                hue = jump * (i - 4);
                sat = 1;
            }
            codes[i] = Color.HSVToColor(new float[]{hue, sat, bri});
        }
        
        // list
        OnClickListener idk = new OnClickListener() {
            @Override
            public void onClick(View p2) {
                RGB.cancel();
                bruh1 = ((ColorDrawable)p2.getBackground()).getColor();
                String rep = chars[Integer.parseInt(((Button)p2).getHint()+"")];
                int loc = Integer.parseInt((bruh2).getText()+"");
                String a = expand(seed.getText().toString());
                ArrayList<String> sp = new ArrayList<String>(Collections.nCopies(100, "."));
                char[] charArrayA = a.toCharArray();
                int copyLength = Math.min(charArrayA.length, sp.size());
                for (int i = 0; i < copyLength; i++) sp.set(i, String.valueOf(charArrayA[i]));
                sp.set(loc, rep);
                String out = String.join("", sp);
                seed.setText(out.replaceAll("\\.+$", ""));
                anim(bruh2);
                dial.cancel();
            }
        };

        for (int n = 0; n < codes.length; n++) {
            Button b = new Button(MainActivity.this);
            b.setOnClickListener(idk);
            b.setBackgroundColor(codes[n]);
            b.setHint(n+"");
            b.setTextColor(negate(codes[n]));
            String hex = "#"+Integer.toHexString(codes[n]).toUpperCase();
            b.setText(hex.equals("#0") ? "#00000000   ." : hex + "   " + (chars[n].equals(" ") ? "SPACE" : chars[n]));
            lay.addView(b);
        }

        AlertDialog.Builder dialb = new AlertDialog.Builder(MainActivity.this);
        dialb.setView(dad);
        dialb.setCancelable(true);
        dialb.setTitle("Select color (scroll down)");
        dialb.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface p1) {
                    RGB.cancel();
                    RGB.removeAllUpdateListeners();
                    bruh2.setBackgroundColor(bruh1);
                    if (copying) {
                        copying = false;
                        clipboard2 = (seed.getText()+"").split("")[bruh3];
                    }
                    
                }
            });
        dial = dialb.create();
        
        // add btns
        Button b;
        int n = 0;
        int w = getResources().getDisplayMetrics().widthPixels / 10;
        while (n < 100) {
            b = new Button(this);
            b.setLayoutParams(new LinearLayout.LayoutParams(w, w));
            b.setText(n+"");
            b.setTextColor(Color.TRANSPARENT);
            b.setBackgroundColor(Color.TRANSPARENT);
            list.add(b);
            if (n % 10 == 0) {
                in = new LinearLayout(this);
                box.addView(in);
            }
            in.addView(b);
            n++;
        }
        
        // onClick
        OnClickListener all = new OnClickListener() {
            @Override
            public void onClick(final View p1) {
                switch (p1.getId()) {
                    case R.id.update:
                        update();
                        break;
                    case R.id.auto:
                        update.setEnabled(!auto.isChecked());
                        update();
                        break;
                    case R.id.export:
                        final ProgressDialog progressDialog = ProgressDialog.show(MainActivity.this, "Please wait", "Generating image...", true);
                        new AsyncTask<Void, Void, Bitmap>() {
                            @Override
                            protected Bitmap doInBackground(Void... params) {
                                return bake(1000, 1000);
                            }
                            @Override
                            protected void onPostExecute(Bitmap bitmap) {
                                progressDialog.dismiss();
                                if (bitmap != null) {
                                    ImageView iv = new ImageView(MainActivity.this);
                                    iv.setImageBitmap(bitmap);
                                    bomb = bitmap;
                                    new AlertDialog.Builder(MainActivity.this)
                                        .setView(iv)
                                        .setPositiveButton("Export", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                                                intent.addCategory(Intent.CATEGORY_OPENABLE);
                                                intent.setType("image/png");
                                                UUID uuid = UUID.randomUUID();
                                                intent.putExtra(Intent.EXTRA_TITLE, "S2P" + uuid.toString().replace("-", "").substring(0, 5) + "_" + seed.getText());
                                                startActivityForResult(intent, SAVE_IMAGE_REQUEST_CODE);
                                            }
                                        })
                                        .setNegativeButton("Cancel", null)
                                        .show();
                                } else {
                                    Toast.makeText(MainActivity.this, "Failed to generate image", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }.execute();
                        break;
                    case R.id.clear:
                        ObjectAnimator fadeOut = ObjectAnimator.ofFloat(box, "alpha", 1f, 0f);
                        fadeOut.setDuration(400);
                        fadeOut.start();
                        fadeOut.addListener(new Animator.AnimatorListener() {
                                @Override
                                public void onAnimationStart(Animator animation) {}
                                @Override
                                public void onAnimationEnd(Animator animation) {
                                    seed.setText("");
                                    update();
                                    box.setAlpha(1);
                                }
                                @Override
                                public void onAnimationCancel(Animator animation) {}
                                @Override
                                public void onAnimationRepeat(Animator animation) {}
                            });
                        break;
                    case R.id.expand:
                        seed.setText(expand(seed.getText()+""));
                        break;
                    case R.id.shorten:
                        seed.setText(summarize(seed.getText()+""));
                        break;
                    default:
                        bruh2 = (Button)p1;
                        bruh1 = ((ColorDrawable)p1.getBackground()).getColor();
                        bruh3 = Integer.parseInt(bruh2.getText().toString());
                        dial.show();
                        paste.setEnabled(clipboard != 999);
                        copy.setEnabled(bruh1 != Color.TRANSPARENT);
                        RGB.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                                @Override
                                public void onAnimationUpdate(ValueAnimator animator) {
                                    p1.setBackgroundColor((int) animator.getAnimatedValue());
                                }
                            });
                        RGB.start();
                }
            }
        };
        
        for (Button bt : list) bt.setOnClickListener(all);
        for (View v : new View[] {update, clear, export, shorten, expand, auto}) v.setOnClickListener(all);
        seed.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {
            }
            @Override
            public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {
                if (auto.isChecked()) update();
                shorten.setEnabled(isSumable(seed.getText()+""));
                expand.setEnabled(isExpandable(seed.getText()+""));
            }
            @Override
            public void afterTextChanged(Editable p1) {
            }
        });
    }
    
    public void byIndex(int n, String s) {
        ArrayList<String> sp = new ArrayList<String>(Collections.nCopies(100, "."));
        char[] charArray = expand(seed.getText().toString()).toCharArray();
        int copyLength = Math.min(charArray.length, sp.size());
        for (int i = 0; i < copyLength; i++) sp.set(i, String.valueOf(charArray[i]));
        toast("index "+n+", "+sp.get(n)+" is now "+s);
        sp.set(n, s);
        String out = String.join("", sp);
        seed.setText(out.replaceAll("\\.+$", ""));
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SAVE_IMAGE_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    OutputStream outputStream = getContentResolver().openOutputStream(uri);
                    if (outputStream != null) {
                        bomb.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
                        outputStream.close();
                        Toast.makeText(MainActivity.this, "Image saved successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Failed to open output stream", Toast.LENGTH_SHORT).show();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, "Failed to save image", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
    
    
    public Bitmap bake(int width, int height) {
        Bitmap image = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        int buttonIndex = 0;
        int numButtons = 100; 
        for (int row = 0; row < height / 100; row++) { 
            for (int col = 0; col < width / 100; col++) {
                Button button = list.get(buttonIndex++ % numButtons);
                int color = Color.TRANSPARENT;
                if (button != null) {
                    color = ((ColorDrawable) button.getBackground()).getColor();
                }
                for (int i = row * 100; i < (row + 1) * 100; i++) {
                    for (int j = col * 100; j < (col + 1) * 100; j++) {
                        image.setPixel(j, i, color);
                    }
                }
            }
        }
        return image;
    }
    
    public int negate(int color) {
        int red = Color.red(color);
        int green = Color.green(color);
        int blue = Color.blue(color);
        double bri = (0.2126 * red) + (0.7152 * green) + (0.0722 * blue);
        if (bri < 128) {
            return Color.WHITE;
        } else {
            return Color.BLACK;
        }
    }
    
    private void anim(final Button button) {
        Animation fadeIn = new AlphaAnimation(0.0f, 1.0f);
        fadeIn.setDuration(450);
        button.startAnimation(fadeIn);
    }
    
    public void none(int i) {
        list.get(i).setBackgroundColor(Color.TRANSPARENT);
    }
    
    public void decrypt(String s) {
        Button b = list.get(index);
        for (int n = 0; n < chars.length; n++) {
            if (s.equals(chars[n])) {
                b.setBackgroundColor(codes[n]);
                return;
            }
        }
        b.setBackgroundColor(codes[0]);
    }
    
    public String expand(String input) {
        String[] parts = input.split("(?<=\\))|(?=\\()");
        StringBuilder result = new StringBuilder();

        for (String part : parts) {
            if (part.matches("\\(.+\\*\\d+\\)")) {
                String[] expandableParts = part.split("[\\(\\)\\*]");
                String character = expandableParts[1];
                int count = Integer.parseInt(expandableParts[2]);
                for (int i = 0; i < count; i++) result.append(character);
            } else result.append(part);
        }
        return result.toString();
    }
    
    public boolean isExpandable(String input) {
        return input.matches(".*\\(.+\\*\\d+\\).*");
    }
    
    public String summarize(String input) {
        StringBuilder result = new StringBuilder();
        int count = 1;
        char prevChar = input.charAt(0);
        for (int i = 1; i < input.length(); i++) {
            char currentChar = input.charAt(i);
            if (currentChar == prevChar) count++;
            else {
                if (count > 1) result.append("(").append(prevChar).append("*").append(count).append(")");
                else result.append(prevChar);
                count = 1;
            }
            prevChar = currentChar;
        }
        if (count > 1) result.append("(").append(prevChar).append("*").append(count).append(")");
        else result.append(prevChar);
        return result.toString();
    }
    public boolean isSumable(String input) {
        for (int i = 0; i < input.length() - 3; i++) {
            char t = input.charAt(i);
            if (t == input.charAt(i + 1) && t == input.charAt(i + 2) && t == input.charAt(i + 3)) return true;
        }
        return false;
    }
    public void update() {
        index = 0;
        String t = seed.getText().toString();
        for (int n = 0; n < 100; n++) none(n);
        if (t.isEmpty()) return;
        String[] arr = expand(t).split("");
        for (int s = 0; s < arr.length; s++) {
            decrypt(arr[s]);
            if (s == (arr.length - 1) && t.length() > old) anim(list.get(index));
            index++;
            if (index == 100) index = 0;
        }
        old = t.length();
    }
}
