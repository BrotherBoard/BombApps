package com.BrotherBoard.S2P;

import android.animation.Animator;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.Nullable;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;
import com.BrotherBoard.S2P.MainActivity;
import com.BrotherBoard.S2P.R;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.UUID;

public class MainActivity extends Activity {
    
    private static final int SAVE_IMAGE_REQUEST_CODE = 1001;
    
    private boolean doubleBackToExitPressedOnce = false;
    private LinearLayout box;
    private LinearLayout in;
    private ArrayList<Button> list;
    private Button clear;
    private EditText seed;
    private int index = 0;
    private int[] codes;
    private String[] chars;
    private Button export;
    private int old = 0;
    private AlertDialog dial;
    private ValueAnimator RGB;
    private int bruh1;
    private Button bruh2;
    private LinearLayout lay;
    private Bitmap bomb;
    
    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }
        this.doubleBackToExitPressedOnce = true;
        toast("Press back again to go bye bye");
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    doubleBackToExitPressedOnce=false;                       
                }
            }, 2000);
    }
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainVoid();
    }
    
    public void storeVar(String varName, String varValue) {
        SharedPreferences VARS = getSharedPreferences("S2P_VARS", MODE_PRIVATE);
        SharedPreferences.Editor editShare = VARS.edit();
        editShare.putString(varName, varValue);
        editShare.apply();
    }
    
    public void nukeVar(String varName) {
        SharedPreferences VARS = getSharedPreferences("S2P_VARS", MODE_PRIVATE);
        SharedPreferences.Editor editShare = VARS.edit();
        editShare.putString(varName, "");
        editShare.apply();
    }
    
    public String getVar(String varName) {
        SharedPreferences VARS = getSharedPreferences("S2P_VARS", MODE_PRIVATE);
        return VARS.getString(varName, varName);
    }
    
    public void toast(String toToast) {
        Toast.makeText(MainActivity.this, toToast, Toast.LENGTH_LONG).show();
    }
    
    public void mainVoid() {
        int dpi = getResources().getDisplayMetrics().densityDpi;
        if( dpi < 340 ) {
            setContentView(R.layout.activity_main);
        } else {
            setContentView(R.layout.main_mdpi);
        }
        
        box = findViewById(R.id.box);
        seed = findViewById(R.id.seed);
        clear = findViewById(R.id.clear);
        export = findViewById(R.id.export);
        list = new ArrayList<Button>();
        RGB = ValueAnimator.ofObject(new ArgbEvaluator(),
                                     Color.RED, Color.MAGENTA, Color.BLUE, Color.CYAN, Color.GREEN, Color.RED);
        RGB.setDuration(1500);
        RGB.setRepeatCount(ValueAnimator.INFINITE);
        lay = new LinearLayout(MainActivity.this);
        lay.setOrientation(1);
        
        // colors
        chars = "0123456789AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz .".split("");
        int len = chars.length;
        codes = new int[len];
        float jump = 350f / (len - 6); // Adjusted for black and white shades
        for (int i = 0; i < len; i++) {
            float hue = 0;
            float sat = 0;
            float bri = 1;

            if (i == 0) {}
            else if (i == 1) bri = 0.75f;
            else if (i == 2) bri = 0.50f;
            else if (i == 3) bri = 0.25f;
            else if (i == 4) bri = 0.12f;
            else if (i == 5) bri = 0;
            else if (i == len - 1) {
                codes[i] = Color.TRANSPARENT;
                continue;
            }
            else {
                hue = jump * (i - 4);
                sat = 1;
            }
            codes[i] = Color.HSVToColor(new float[]{hue, sat, bri});
        }
        
        // list
        OnClickListener idk = new OnClickListener() {
            @Override
            public void onClick(View p2) {
                RGB.cancel();
                bruh1 = ((ColorDrawable)p2.getBackground()).getColor();
                String rep = chars[Integer.parseInt(((Button)p2).getHint()+"")];
                int loc = Integer.parseInt((bruh2).getText()+"");
                String a = seed.getText().toString();
                ArrayList<String> sp = new ArrayList<String>(Collections.nCopies(100, "."));
                char[] charArrayA = a.toCharArray();
                int copyLength = Math.min(charArrayA.length, sp.size());
                for (int i = 0; i < copyLength; i++) {
                    sp.set(i, String.valueOf(charArrayA[i]));
                }
                sp.set(loc, rep);
                String out = String.join("", sp);
                seed.setText(out.replaceAll("\\.+$", ""));
                anim(bruh2);
                dial.cancel();
            }
        };

        for (int n = 0; n < codes.length; n++) {
            Button b = new Button(MainActivity.this);
            b.setOnClickListener(idk);
            b.setBackgroundColor(codes[n]);
            b.setHint(n+"");
            b.setTextColor(negate(codes[n]));
            String hex = "#"+Integer.toHexString(codes[n]).toUpperCase();
            b.setText(hex.equals("#0") ? "#00000000" : hex);
            lay.addView(b);
        }

        ScrollView scroll = new ScrollView(MainActivity.this);
        scroll.addView(lay);
        scroll.setPadding(15, 15, 15, 15);

        AlertDialog.Builder dialb = new AlertDialog.Builder(MainActivity.this);
        dialb.setView(scroll);
        dialb.setCancelable(true);
        dialb.setTitle("Select color (scroll down)");
        dialb.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface p1) {
                    RGB.cancel();
                    RGB.removeAllUpdateListeners();
                    bruh2.setBackgroundColor(bruh1);
                }
            });
        dial = dialb.create();
        
        // add btns
        Button b;
        int n = 0;
        int w = getResources().getDisplayMetrics().widthPixels / 10;
        while (n < 100) {
            b = new Button(this);
            b.setLayoutParams(new LinearLayout.LayoutParams(w, w));
            b.setText(n+"");
            b.setTextColor(Color.TRANSPARENT);
            b.setBackgroundColor(Color.TRANSPARENT);
            list.add(b);
            if (n % 10 == 0) {
                in = new LinearLayout(this);
                box.addView(in);
            }
            in.addView(b);
            n++;
        }
        clear.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {
                ObjectAnimator fadeOut = ObjectAnimator.ofFloat(box, "alpha", 1f, 0f);
                fadeOut.setDuration(400);
                fadeOut.start();
                fadeOut.addListener(new Animator.AnimatorListener() {
                        @Override
                        public void onAnimationStart(Animator animation) {}
                        @Override
                        public void onAnimationEnd(Animator animation) {
                        seed.setText("");
                        update();
                        box.setAlpha(1);
                        }
                        @Override
                        public void onAnimationCancel(Animator animation) {}
                        @Override
                        public void onAnimationRepeat(Animator animation) {}
                    });
            }
        });
        OnClickListener ear = new OnClickListener() {
            @Override
            public void onClick(final View p1) {
                bruh2 = (Button)p1;
                bruh1 = ((ColorDrawable)p1.getBackground()).getColor();
                dial.show();
                RGB.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                        @Override
                        public void onAnimationUpdate(ValueAnimator animator) {
                            p1.setBackgroundColor((int) animator.getAnimatedValue());
                        }
                    });
                RGB.start();
            }
        };
        for (Button bt : list) {
            bt.setOnClickListener(ear);
        }
        seed.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {
            }
            @Override
            public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {
                update();
            }
            @Override
            public void afterTextChanged(Editable p1) {
            }
        });
        export.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View p1) {
                    final ProgressDialog progressDialog = ProgressDialog.show(MainActivity.this, "Please wait", "Generating image...", true);
                    new AsyncTask<Void, Void, Bitmap>() {
                        @Override
                        protected Bitmap doInBackground(Void... params) {
                            return bake(1000, 1000);
                        }
                        @Override
                        protected void onPostExecute(Bitmap bitmap) {
                            progressDialog.dismiss();
                            if (bitmap != null) {
                                ImageView iv = new ImageView(MainActivity.this);
                                iv.setImageBitmap(bitmap);
                                bomb = bitmap;
                                new AlertDialog.Builder(MainActivity.this)
                                    .setView(iv)
                                    .setPositiveButton("Export", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                                            intent.addCategory(Intent.CATEGORY_OPENABLE);
                                            intent.setType("image/png");
                                            UUID uuid = UUID.randomUUID();
                                            intent.putExtra(Intent.EXTRA_TITLE, "S2P" + uuid.toString().replace("-", "").substring(0, 5) + "_" + seed.getText());
                                            startActivityForResult(intent, SAVE_IMAGE_REQUEST_CODE);
                                        }
                                    })
                                    .setNegativeButton("Cancel", null)
                                    .show();
                            } else {
                                Toast.makeText(MainActivity.this, "Failed to generate image", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }.execute();
                }
            });
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SAVE_IMAGE_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    OutputStream outputStream = getContentResolver().openOutputStream(uri);
                    if (outputStream != null) {
                        bomb.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
                        outputStream.close();
                        Toast.makeText(MainActivity.this, "Image saved successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Failed to open output stream", Toast.LENGTH_SHORT).show();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, "Failed to save image", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
    
    
    public Bitmap bake(int width, int height) {
        Bitmap image = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        int buttonIndex = 0;
        int numButtons = 100; 
        for (int row = 0; row < height / 100; row++) { 
            for (int col = 0; col < width / 100; col++) {
                Button button = list.get(buttonIndex++ % numButtons);
                int color = Color.TRANSPARENT;
                if (button != null) {
                    color = ((ColorDrawable) button.getBackground()).getColor();
                }
                for (int i = row * 100; i < (row + 1) * 100; i++) {
                    for (int j = col * 100; j < (col + 1) * 100; j++) {
                        image.setPixel(j, i, color);
                    }
                }
            }
        }
        return image;
    }
    
    public int negate(int color) {
        int red = Color.red(color);
        int green = Color.green(color);
        int blue = Color.blue(color);
        double bri = (0.2126 * red) + (0.7152 * green) + (0.0722 * blue);
        if (bri < 128) {
            return Color.WHITE;
        } else {
            return Color.BLACK;
        }
    }
    
    private void anim(final Button button) {
        Animation fadeIn = new AlphaAnimation(0.0f, 1.0f);
        fadeIn.setDuration(450);
        button.startAnimation(fadeIn);
    }
    
    public void none(int i) {
        list.get(i).setBackgroundColor(Color.TRANSPARENT);
    }
    
    public void decrypt(String s) {
        Button b = list.get(index);
        for (int n = 0; n < chars.length; n++) {
            if (s.equals(chars[n])) {
                b.setBackgroundColor(codes[n]);
                return;
            }
        }
        b.setBackgroundColor(codes[0]);
    }
    
    public void update() {
        index = 0;
        String t = seed.getText().toString();
        for (int n = 0; n < 100; n++) none(n);
        if (t.isEmpty()) return;
        String[] arr = t.split("");
        for (int s = 0; s < arr.length; s++) {
            decrypt(arr[s]);
            if (s == (arr.length - 1) && t.length() > old) anim(list.get(index));
            index++;
            if (index == 100) index = 0;
        }
        old = t.length();
    }
}
