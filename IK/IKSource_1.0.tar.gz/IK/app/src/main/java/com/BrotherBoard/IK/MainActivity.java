package com.BrotherBoard.IK;
 
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import java.util.ArrayList;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final ArrayList<View> keys = findViewById(R.id.charView).getTouchables();
        ((CheckBox) findViewById(R.id.caps)).setOnCheckedChangeListener(new OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    for (View key : keys) {
                        Button keyb = (Button) key;
                        String chr = keyb.getText()+"";
                        keyb.setText(p2 ? chr.toUpperCase() : chr.toLowerCase());
                    }
                }
        });
        OnClickListener ear = new OnClickListener() {
            @Override
            public void onClick(View p1) {
                EditText out = findViewById(R.id.out);
                String old = out.getText()+"";
                String a = ((Button) p1).getText()+"";
                out.setText(a.equals("<×") ? old.substring(0, (old.length() > 0) ? old.length() - 1 : 0) : a.isEmpty() ? old+" " : old+a);
            }       
        };
        for (View v : keys) {
            v.setOnClickListener(ear);
        }
    }
}
