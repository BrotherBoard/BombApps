package com.BrotherBoard.CP;
 
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.*;
import android.widget.*;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.text.*;

public class MainActivity extends Activity {
    
    public String Y_text(int type) {
        EditText Y = findViewById(R.id.Y);
        String Y_text = Y.getText().toString();
        if(Y_text.equals("-")) {
            Y_text = "0"; Y.setText("");
        }
        TextView Static = findViewById(R.id.Static);
        if (Y_text.isEmpty()) {
            Y_text = "0";
        }
        int Y_text_int = Integer.parseInt(Y_text);
        if(type == 0) {
            ++Y_text_int;
        } else if (type == 1) {
            --Y_text_int;
        } else {
            Y_text_int = (Y_text_int * 1000 / 40);
            Static.setText("Static: "+Y_text_int);
        }
        Y_text = Y_text_int+"";
        return Y_text;
    }

    public void Solve() {
        final EditText Answer = findViewById(R.id.Ans);
        String Ans = Y_text(2);
        if(Ans.startsWith("-")) {
            if(Ans.endsWith("25")){Ans="-i";}
            else if(Ans.endsWith("75")){Ans="i";}
        } else {
            if(Ans.endsWith("25")){Ans="i";}
            else if(Ans.endsWith("75")){Ans="-i";}
        }
        if(Ans.endsWith("00") || Ans.equals("0")){ Ans="1";}
        else if(Ans.endsWith("50")){ Ans="-1";}
        Answer.setText(Ans);
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button Solve = findViewById(R.id.Solve);
        Button Plus = findViewById(R.id.Plus);
        Button Minus = findViewById(R.id.Minus);
        final EditText Y = findViewById(R.id.Y);
        final Switch Auto = findViewById(R.id.Auto);
        
        final TextWatcher Watch_Y = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {}
            @Override
            public void onTextChanged(CharSequence p1, int p2, int p3, int p4) { Solve();}
            @Override
            public void afterTextChanged(Editable p1) {}
        };
        
        Auto.setOnCheckedChangeListener(new OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    if(Auto.isChecked()) {
                        Y.addTextChangedListener(Watch_Y); Solve.setEnabled(false);
                    } else {
                        Y.removeTextChangedListener(Watch_Y); Solve.setEnabled(true);
                    }
                }
        });
        
        Plus.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {Y.setText(Y_text(0));}
        });
        
        Minus.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View p1) {Y.setText(Y_text(1));}
            });
            
        Solve.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {Solve();}
        });
        
        Auto.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View p1) {Solve();}
            });
    }
}
