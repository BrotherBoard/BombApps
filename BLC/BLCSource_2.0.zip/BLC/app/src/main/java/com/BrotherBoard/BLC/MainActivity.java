package com.BrotherBoard.BLC;
 
import android.animation.LayoutTransition;
import android.app.Activity;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.transition.Fade;
import android.transition.TransitionManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.BrotherBoard.BLC.MainActivity;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    
    public String exec(String cmd) {
        String out = "";
        try {
            Process in = Runtime.getRuntime().exec(cmd);
            BufferedReader reader = new BufferedReader(new InputStreamReader(in.getInputStream()));
            out=reader.readLine();
        } catch (IOException e) {}
        return out;
    }
    public void makeToast(String toToast) {
        Toast.makeText(MainActivity.this, toToast, Toast.LENGTH_SHORT).show();
    }

    public void fadeOut() {
        ViewGroup rootView = findViewById(android.R.id.content);
        TransitionManager.beginDelayedTransition(rootView, new Fade(Fade.IN).setDuration(500));
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loading);
        final TextView loadText = findViewById(R.id.loadingStatus);
        final TextView loadText2 = findViewById(R.id.loadingText);
        final ProgressBar spin = findViewById(R.id.spin);
        final Button tryAgain = findViewById(R.id.tryAgain);
        tryAgain.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {
                recreate();
            }
        });
        CountDownTimer loading = new CountDownTimer(3000, 5) {
            @Override
            public void onTick(long p1) {
                ProgressBar poggers = findViewById(R.id.poggers);
                poggers.setProgress(poggers.getProgress() + 1);
            }
            @Override
            public void onFinish() {
                String test = exec("su -c pwd");
                if (test == null) {
                    loadText.setText("attempt to execute pwd returned null, are you rooted?");
                    tryAgain.setVisibility(View.VISIBLE);
                    loadText2.setText("Error");
                    spin.setVisibility(View.GONE);
                } else {
                    // user is rooted
                    fadeOut();
                    wasCreated();
                }
            }
        }.start();
    }
        
    public void wasCreated() {
        setContentView(R.layout.activity_main);
        final Button apply = findViewById(R.id.apply);
        LayoutTransition transition = new LayoutTransition();
        transition.enableTransitionType(LayoutTransition.CHANGING);
        ((LinearLayout)findViewById(R.id.rootView)).setLayoutTransition(transition);
        apply.setEnabled(false);
        Button reset = findViewById(R.id.reset);
        final EditText prcnt = findViewById(R.id.prcnt);
        final TextView tipa = findViewById(R.id.tipa);
        exec("su -c dumpsys battery reset level");
        final String old = exec("su -c dumpsys battery get level");
        tipa.setText("Current percentage: "+old);
        prcnt.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {
                }
                @Override
                public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {
                    apply.setEnabled(!p1.toString().isEmpty() && Integer.parseInt(p1+"") > 0);
                }
                @Override
                public void afterTextChanged(Editable p1) {
                }
        });
        
        reset.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {
                exec("su -c dumpsys battery reset");
                tipa.setText("Current percentage: "+old);
            }
        });
        
        apply.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {
                exec("su -c dumpsys battery set level "+prcnt.getText());
                tipa.setText("Current percentage: "+old+"\nNew percentage:"+prcnt.getText());
            }
        });
    }
}
