package com.BrotherBoard.CFT;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.InputType;
import android.transition.Fade;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;
import java.io.StringReader;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loading);
        TextView ver = findViewById(R.id.version);
        ver.setText("v6.0");
        load();
    }
    
    public void load() {
        final ProgressBar poggers = findViewById(R.id.poggers);
        final TextView loadingStatus = findViewById(R.id.loadingStatus);

        new CountDownTimer(3000, 20) {
            @Override
            public void onTick(long p1) {
                poggers.setProgress(poggers.getProgress() + 1);
                loadingStatus.setText("Setting up voids");
            }
            @Override
            public void onFinish() {
                ViewGroup rootView = findViewById(android.R.id.content);
                Transition fade = new Fade(Fade.IN);
                fade.setDuration(500);
                TransitionManager.beginDelayedTransition(rootView, fade);
                if((exec("pwd").isEmpty()) ? false : true) {
                    if(hasXml()) {
                        mainVoid();
                    } else {
                        warn("File not found", "Attempt to read /system/cameradata/camera-feature.xml failed\nare you running OneUI?");
                    }
                } else {
                    warn("No root", "Attempt to execute pwd returned null, are you rooted?");
                }
            }
        }.start();
    }
    
    public void warn(String bigText, String smallText) {
        final ProgressBar pog = findViewById(R.id.poggers);
        final TextView loadMain = findViewById(R.id.loadingText);
        final TextView load = findViewById(R.id.loadingStatus);
        final ProgressBar spin = findViewById(R.id.spin);
        final Button tryAgain = findViewById(R.id.tryAgain);
        final ProgressBar poggers = findViewById(R.id.poggers);
        loadMain.setText(bigText);
        load.setText(smallText);
        load.setTextColor(Color.RED);
        pog.setAlpha(0.5f);
        spin.setVisibility(View.GONE);
        tryAgain.setVisibility(View.VISIBLE);
        tryAgain.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    tryAgain.setVisibility(View.INVISIBLE);
                    spin.setVisibility(View.VISIBLE);
                    load.setTextColor(Color.GRAY);
                    pog.setAlpha(1.0f);
                    poggers.setProgress(0);
                    loadMain.setText("Initializing");
                    load();
                }
            });
    }
    
    public boolean hasXml() {
        if(exec("ls /system/cameradata/camera-feature.xml | grep 'camera-feature.xml'").isEmpty()) {
            return false;
        } else {
            return true;
        }
    }
    
    // static strings
    String n = "\n";
    String getNumberOut = "";
    String getNumberOut2 = "";

    // base #0 (add line to lines[])
    // environment variables
    String[] lines = {
        "<local name=\"SHOOTING_MODE_FUN\" back=\"FUN\" front=\"FUN\" enable=\"true\" more=\"false\" order=\"1\" />",
        "",
        "<local name=\"SHOOTING_MODE_LIVE_FOCUS\" back=\"LIVE_FOCUS\" front=\"SELFIE_FOCUS\" enable=\"true\" more=\"false\" order=\"2\" info=\"6\"/>",
        "",
        "<local name=\"SHOOTING_MODE_FOOD\" back=\"FOOD\" enable=\"true\" more=\"true\" order=\"8\" info=\"2\"/>",
        "<local name=\"SHOOTING_MODE_SINGLE_TAKE_PHOTO\" back=\"SINGLE_TAKE_PHOTO\" front=\"SINGLE_TAKE_PHOTO\" enable=\"true\" more=\"true\" order=\"6\" preview-size=\"1440x1080\" capture-size=\"3264x2448\" front-capture-size=\"2944x2208\" info=\"1\" big-info=\"true\"/>",
        "<local name=\"SHOOTING_MODE_HYPER_LAPSE\" back=\"HYPER_LAPSE\" front=\"HYPER_LAPSE\" enable=\"true\" more=\"true\" order=\"14\" preview-size=\"1280x720\" capture-size=\"1920x1080\" info=\"5\"/>",
        "<local name=\"SUPPORT_SWITCH_FACING_WHILE_RECORDING\" value=\"true\" />"
    };

    // main code
    public String getVar(int varId, int mode) {
        String featureLine;
        String featureName;
        try{
        featureLine = lines[varId];
        } catch (ArrayIndexOutOfBoundsException e) {
            return "none";
        }
        featureName = (featureLine.substring(featureLine.indexOf("name=\"")+6));
        featureName = featureName.substring(0, featureName.indexOf("\""));
        return (mode == 1) ? featureLine : featureName;
    }
    // methods
    public String exec(String in) {
        String out = "";
        try {
            Process su = Runtime.getRuntime().exec("su");
            DataOutputStream outputStream = new DataOutputStream(su.getOutputStream());
            outputStream.writeBytes("mount -o rw,remount /"+n+in+n); outputStream.flush();
            outputStream.writeBytes("exit\n"); outputStream.flush();
            BufferedReader inputStream = new BufferedReader(new InputStreamReader(su.getInputStream()));
            String line;
            while ((line = inputStream.readLine()) != null) {
                out+=line+n;
            }
            su.waitFor();
        } catch (IOException e) {} catch (InterruptedException e) {}
        return out;
    }

    public void toast(String toToast) {
        Toast.makeText(MainActivity.this, toToast, Toast.LENGTH_LONG).show();
    }

    public void getNumber(final boolean listMode) {
        String title = (!listMode) ?  "Enter feature ID" : "Define Feature";
        String msg = (!listMode) ? "This is for debugging purposes, feature ID is the array member of lines[int input] which lines are stored in, get it from \"Define Feature\" menu" : "A list of feature ID's which their features can be retrived from \"Get Feature\" menu";
        final EditText view = new EditText(this);
        view.setInputType(InputType.TYPE_CLASS_NUMBER);
        view.setHint("Feature ID");
        AlertDialog.Builder lmao = new AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(msg)
            .setView(R.layout.tips)
            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    if(!listMode) {
                    String meh = view.getText().toString().isEmpty() ? "00" : view.getText().toString();
                    if(meh == "00") {
                        ipush("Debug: empty input");
                    } else {
                        getNumberOut = getVar(Integer.parseInt(meh), 0);
                        getNumberOut2 = getVar(Integer.parseInt(meh), 1);
                        if(getNumberOut.isEmpty() || getNumberOut.equals("none")) {
                            ipush("GetFeature: no such element");
                        } else {
                            ipush("==GetFeature START==\n"+getNumberOut2+n+getNumberOut+"\n==GetFeature END==");
                        }
                    }
                    }
                }
            })
            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {}
            });
            if(!listMode) {
                lmao.setView(view);
            }
            lmao.show();
    }

    public void more(){
        findViewById(R.id.more).setEnabled(false);
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        final List items = Arrays.asList("Clear logs", "Export logs to device", "Delete logs from device", "Get Feature", "Define Feature", "Close App");
        final EditText logbox = findViewById(R.id.logbox);
        builder.setTitle("More options");
        ListView listView = new ListView(MainActivity.this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, items);
        listView.setAdapter(adapter);
        builder.setView(listView);
        final AlertDialog dialog = builder.create();
        dialog.show();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4) {
                    switch (p3) {
                        case 0:
                            toast("cleared logs");
                            logbox.setText("");
                            break;
                        case 1:
                            exec("echo '\nSTART OF EXPORTED LOGS\n"+logbox.getText().toString()+"' >> /sdcard/CFTLogs.txt");
                            toast("Exported logs to /sdcard/CFTLogs.txt");
                            break;
                        case 2:
                            exec("rm -rf /sdcard/CFTLogs.txt");
                            toast("Deleted logs from /sdcard/CFTLogs.txt");
                            break;
                        case 3:
                            getNumber(false);
                            break;
                        case 5:
                            finishAfterTransition();
                            break;
                        case 4:
                            getNumber(true);
                            break;
                    }
                    dialog.dismiss();
                }
            });
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface p1) {
                    findViewById(R.id.more).setEnabled(true);
                }
        });
    }

    public void ipush(String toPush) {
        EditText logbox = findViewById(R.id.logbox);
        logbox.setText(logbox.getText().toString()+"\n"+toPush);
    }

    public void bqp() {
        exec("cp /system/cameradata/camera-feature.xml "+getFilesDir().getAbsolutePath());
        ipush("CFT: backup was created in the app's data");
    }

    public String getFeature(String feature) {
        return exec("su -c cat /system/cameradata/camera-feature.xml | grep "+feature);
    }

    public void rstore() {
        new CountDownTimer(500, 500) {
            @Override
            public void onTick(long p1) {}
            @Override
            public void onFinish() {
                exec("cp "+getFilesDir().getAbsolutePath()+"/camera-feature.xml /system/cameradata/");
                ipush("CFT: restored xml from app's data"); Switches(true, 0);
            }
        }.start();
    }

    public void rstore_stock() {
        exec("cp "+getFilesDir().getAbsolutePath()+"/backup/camera-feature.xml /system/cameradata"); Switches(true, 0);
    }

    public void applyTemp(boolean overwrite) {
        String which = (overwrite) ? ">" : ">>";
        exec("cat "+getFilesDir().getAbsolutePath()+"/.temp "+which+" /system/cameradata/camera-feature.xml");
        killCamera();
    }

    public void nukeFeature(String toNuke) {
        exec("cat /system/cameradata/camera-feature.xml | sed '/"+toNuke+"/d' > "+getFilesDir().getAbsolutePath()+"/.temp");
        applyTemp(true);
    }

    public void addFeature(String toAdd) {
        exec("echo '"+toAdd+"' > "+getFilesDir().getAbsolutePath()+"/.temp");
        applyTemp(false);
    }

    public void tryAndRead() {
        if(getFeature("FRONT_CAMERA").isEmpty()) {
            ipush("ERROR: unable to read camera-feature.xml, please report this");
            Switches(false, 1);
        }
    }

    public void fps(final boolean enable) {
        tryAndRead();
        String res = getCurrentResolution();
        if(enable) {
            ipush("CFT: wrote a new line with resolution "+res+"_60FPS");
            String line = getFeature("MAP_"+res+" | grep BACK | grep -v FPS").replace(res, res+"_60FPS");
            addFeature(line);
        } else {
            ipush("CFT: nuked line with resolution "+res+"_60FPS");
            nukeFeature("_60FPS");
        }
    }

    public void blenk(final int Id, final boolean mode) {
        Switches(false, 1);
        new CountDownTimer(700, 700) {
            @Override
            public void onTick(long p1) {}
            @Override
            public void onFinish() {
                Switches(true, 1);
                switch (Id) {
                    case 1:
                        fps(mode); break;
                    case 3:
                        rstore(); break;
                    default:
                        enableFeature(Id, mode); break;
                }
            }
        }.start();
    }

    public void enableFeature(int featureId, boolean enable) {
        tryAndRead();
        String method = ""; String feature = "";
        feature = getVar(featureId, 1);
        method = getVar(featureId, 2);
        if(enable) {
            ipush("CFT: wrote a new line with method "+method);
            addFeature(feature);
        } else {
            ipush("CFT: nuked line with method "+method);
            nukeFeature(method);
        }
    }

    public void safe() {
        final AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
            .setTitle("Restore stock xml") .setCancelable(false)
            .setMessage("This will restore the camera-feature.xml backed up on first app launch\n\nPress OK to continue")
            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ipush("CFT: restoring stock camera-feature.xml from "+getFilesDir().getAbsolutePath()+"/backup");
                    rstore_stock(); Switches(true, 1);
                }
            })
            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ipush("CFT: no restore was done"); Switches(true, 1);
                }
            })
            .create();
        dialog.show();
    }

    // for switches
    public void killCamera() {
        exec("am force-stop com.sec.android.app.camera");
    }

    public boolean cameraIsRunning() {
        return exec("pidof com.sec.android.app.camera") != "";
    }

    // base #1 (add switch to Switches)
    public void Switches(boolean enable, int mode) {
        Switch fps = findViewById(R.id.fps_switch);
        Switch fun = findViewById(R.id.fun_switch);
        Switch port = findViewById(R.id.port_switch);
        Switch food = findViewById(R.id.food_switch);
        Switch single = findViewById(R.id.single_switch);
        Switch hyper = findViewById(R.id.hyper_switch);
        Button launch = findViewById(R.id.launch);
        Switch switch_switch = findViewById(R.id.switch_switch);
        ProgressBar busy = findViewById(R.id.busy);
        if(mode == 1) {
            fps.setEnabled(enable);
            fun.setEnabled(enable);
            port.setEnabled(enable);
            food.setEnabled(enable);
            single.setEnabled(enable);
            hyper.setEnabled(enable);
            launch.setEnabled(enable);
            switch_switch.setEnabled(enable);
            if(enable) {
            busy.setVisibility(View.INVISIBLE);
            } else {
            busy.setVisibility(View.VISIBLE);
            }
        } else {
            fps.setChecked(getFeature("_60FPS") != "");
            fun.setChecked(getFeature(getVar(0, 2)) != "");
            port.setChecked(getFeature(getVar(2, 2)) != "");
            food.setChecked(getFeature(getVar(4, 2)) != "");
            single.setChecked(getFeature(getVar(5, 2)) != "");
            hyper.setChecked(getFeature(getVar(6, 2)) != "");
            switch_switch.setChecked(getFeature(getVar(7, 2)) != "");
        }
    }

    CountDownTimer cdown = new CountDownTimer(1500, 1500) {
        @Override
        public void onTick(long p1) {
        }
        @Override
        public void onFinish() {
            Switches(true, 1);
        }
    };

    public void blink() {
        Switches(false, 1);
        cdown.start();
    }

    public String getCurrentResolution() {
        String line = getFeature("BACK_CAMERA_RECORDING_DEFAULT_RESOLUTION | grep -o [0-9.x]");
        String res = ""; line = line.replace("\n", ""); res = line.replace("x", "X");
        return res;
    }

    public void fishKill() {
        Button kill = findViewById(R.id.kill); kill.setEnabled(cameraIsRunning());
    }

    public void mainVoid() {
        Resources resources = getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        int dpi = metrics.densityDpi;
        if( dpi < 410 ) {
            setContentView(R.layout.activity_main);
            ipush("DPI less than 410 ("+dpi+") applying wide layout");
        } else {
            setContentView(R.layout.main_mdpi);
            ipush("DPI more than 410 ("+dpi+") applying small layout");
        }
        // on start
        Switches(true, 0);

        // environment variables
        String root = getFilesDir().getAbsolutePath();
        String file = "camera-feature.xml";
        String s = " "; String sep = " | ";

        // one time backup
        String check = exec("ls "+root+"/backup"+sep+" grep "+file);
        if(check.isEmpty() || check == null) {
            exec("mkdir "+root+"/backup");
            exec("cp "+"/system/cameradata/"+file+s+root+"/backup");
            ipush("CFT: revert backup was made in "+root+"/backup");
        }

        // elements
        Button backup = findViewById(R.id.backup);
        final Button restore = findViewById(R.id.restore);
        Button restore_stock = findViewById(R.id.restore_stock);
        Button launch = findViewById(R.id.launch);
        Button kill = findViewById(R.id.kill); fishKill();
        Button more = findViewById(R.id.more);
        // check if backed up before
        String temp = exec("ls "+root+sep+"grep "+file);
        if(temp.equals("")) {
            ipush("CFT: no backup found");
            restore.setEnabled(false);
        } else {
            ipush("CFT: found backup in "+root);
            TextView location = findViewById(R.id.location);
            location.setText("Currently backed up in app/files");
        }

        // onClickListeners
        // base #2 (define and add onclick listener to switch)
        final Switch fps_switch = findViewById(R.id.fps_switch);
        final Switch port_switch = findViewById(R.id.port_switch);
        final Switch fun_switch = findViewById(R.id.fun_switch);
        final Switch food_switch = findViewById(R.id.food_switch);
        final Switch single_switch = findViewById(R.id.single_switch);
        final Switch hyper_switch = findViewById(R.id.hyper_switch);
        final Switch switch_switch = findViewById(R.id.switch_switch);
        View.OnClickListener ear = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.backup:
                        bqp();
                        restore.setEnabled(true);
                        break;
                    case R.id.restore:
                        blenk(3, true);
                        break;
                    case R.id.restore_stock:
                        Switches(false, 1);
                        safe();
                        break;
                    case R.id.launch:
                        exec("am start com.sec.android.app.camera");
                        break;
                    case R.id.kill:
                        killCamera();
                        break;
                    case R.id.more:
                        more();
                        break;
                    case R.id.fps_switch:
                        blenk(1, fps_switch.isChecked());
                        break;
                    case R.id.port_switch:
                        blenk(2, port_switch.isChecked());
                        break;
                    case R.id.fun_switch:
                        blenk(0, fun_switch.isChecked());
                        break;
                    case R.id.food_switch:
                        blenk(4, food_switch.isChecked());
                        break;
                    case R.id.single_switch:
                        blenk(5, single_switch.isChecked());
                        break;
                    case R.id.hyper_switch:
                        blenk(6, hyper_switch.isChecked());
                        break;
                    case R.id.switch_switch:
                        blenk(7, switch_switch.isChecked());
                        break;
                }
                fishKill();
            }
        };
        // base #3 (add switch as array member)
        Button[] btn = {backup, restore, restore_stock, launch, kill, more, fps_switch, fun_switch, port_switch, single_switch, food_switch, hyper_switch, switch_switch};
        for (Button b : btn) {
            b.setOnClickListener(ear);
        }
    }
}
