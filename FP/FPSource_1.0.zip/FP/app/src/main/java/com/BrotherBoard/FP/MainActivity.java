package com.BrotherBoard.FP;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.Toast;

@SuppressLint("NewApi")
public class MainActivity extends Activity {
    private FingerprintManager fingerprintManager;
    private EditText logbox;
    private EditText logbox2;
    private Switch doublee;
    private EditText nice;
    private boolean authenticationInProgress = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initializeViews();
        initializeAuthentication();
    }
    private void initializeViews() {
        logbox = findViewById(R.id.logbox);
        logbox2 = findViewById(R.id.logbox2);
        doublee = findViewById(R.id.doublee);
        nice = findViewById(R.id.nice);

        Button lmaoButton = findViewById(R.id.lmao);
        lmaoButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    logbox.setText("");
                    logbox2.setText("");
                }
            });
        Button restart = findViewById(R.id.restart);
        restart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    recreate();
                }
            });
        doublee.setOnCheckedChangeListener(new OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    ((Switch)findViewById(R.id.lmfao)).setEnabled(p2);
                    ((Switch)findViewById(R.id.lmfao)).setChecked(false);
                }
            });
        doublee.setChecked(true);
    }
    private void initializeAuthentication() {
        fingerprintManager = (FingerprintManager) getSystemService(Context.FINGERPRINT_SERVICE);
        if (fingerprintManager != null && fingerprintManager.isHardwareDetected()) {
            showToast("Fingerprint hardware detected");
        } else {
            showToast("Fingerprint hardware not detected");
        }

        if (checkSelfPermission(Manifest.permission.USE_FINGERPRINT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.USE_FINGERPRINT}, 0);
        } else {
            resetFingerprintAuthentication();
        }
    }
    private void resetFingerprintAuthentication() {
        authenticationInProgress = false;
        logbox2.append("Resetting fingerprint authentication ℹ️\n");
        startFingerprintAuthentication();
    }
    private void startFingerprintAuthentication() {
        logbox2.append("Starting fingerprint authentication 🔰\n");
        if (!authenticationInProgress) {
            authenticationInProgress = true;
            fingerprintManager.authenticate(null, null, 0, authenticationCallback, null);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        logbox2.append("Permission result received 💯\n");
        if (requestCode == 0) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                resetFingerprintAuthentication();
            } else {
                showToast("Fingerprint permission not granted");
            }
        }
    }

    private int held = 0;
    private boolean doubled = false;
    private int interval = 1000;
    private final FingerprintManager.AuthenticationCallback authenticationCallback = new FingerprintManager.AuthenticationCallback() {
        @Override
        public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {
            super.onAuthenticationSucceeded(result);
            if (((Switch)findViewById(R.id.doublee)).isChecked()) {
                held++;
                interval = (!nice.getText().toString().isEmpty()) ? Integer.parseInt(nice.getText().toString()) : 400;
                logbox2.append("Queued request ("+held+") for "+interval+"ms ⭕️\n");
                new CountDownTimer(interval, interval / 50) {
                    @Override
                    public void onTick(long p1) {
                        //logbox.append(100 - (p1 * 100 / interval) + " ");
                        ((ProgressBar)findViewById(R.id.pog)).setProgress(Integer.parseInt(100 - (p1 * 100 / interval) + ""));
                    }
                    @Override
                    public void onFinish() {
                        ((ProgressBar)findViewById(R.id.pog)).setProgress(100);
                        if (held > 1) {
                            logbox.append("Double touch ✅✅️️️️\n");
                            ((ProgressBar)findViewById(R.id.pog)).setAlpha(0.1f);
                            if (((Switch)findViewById(R.id.lmfao)).isChecked()) showToast("Double touch ✅️✅️");
                            logbox2.append("Treating as double touch 💯\n");
                            doubled = true;
                        } else {
                            if (doubled) {
                                doubled = false;
                                logbox2.append("Active ("+held+") 💢\n");
                                ((ProgressBar)findViewById(R.id.pog)).setAlpha(1.0f);
                            } else {
                                logbox.append("Single touch ✅️️️\n");
                                logbox2.append("Treating as single touch 👌\n");
                            }
                        }
                        held = 0;
                    }
                }.start();
            } else {
                logbox.append("Single touch ✅️️️\n");
            }
            resetFingerprintAuthentication();
        }
        @Override
        public void onAuthenticationFailed() {
            super.onAuthenticationFailed();
            logbox.append("Fingerprint doesn't match ❌️\n");
            authenticationInProgress = false;
        }
    };
    @Override
    protected void onResume() {
        super.onResume();
        logbox2.append("Resuming activity 🔄\n");
        resetFingerprintAuthentication();
    }
    private void showToast(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }
}

