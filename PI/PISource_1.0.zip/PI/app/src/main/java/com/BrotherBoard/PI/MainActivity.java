package com.BrotherBoard.PI;
 
import android.app.Activity;
import android.graphics.Color;
import java.text.DecimalFormat;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.Spannable;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.CheckBox;
import android.os.CountDownTimer;

public class MainActivity extends Activity { 

    private EditText logbox;
    private EditText Xt;
    private CheckBox stack;
    private Button start;
    private Button hold;
    private Button stop;
    private Button clear;
    private CountDownTimer cdown;
    private double pi = 0;
    private double onx1_v;
    private double onx2_v;
    private int X;
    private EditText xp;
    private EditText px;
    private EditText onx1;
    private EditText onx2;
    private String log;
    private boolean running = false;
    private double px_v;
    private double xp_v;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
            
        hold = findViewById(R.id.hold);
        start = findViewById(R.id.start);
        stop = findViewById(R.id.stop);
        logbox = findViewById(R.id.logbox);
        clear = findViewById(R.id.clear);
        Xt = findViewById(R.id.X);
        stack = findViewById(R.id.stack);
        xp = findViewById(R.id.var_xp);
        onx2 = findViewById(R.id.var_onx2);
        onx1 = findViewById(R.id.var_onx1);
        px = findViewById(R.id.var_px);
        
        stop.setEnabled(false);
        stack.setChecked(true);
        
        logbox.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {}
                @Override
                public void afterTextChanged(Editable s) {
                    String inputText = s.toString();
                    String targetText = "3.1415926535897";
                    int endIndex = 0;
                    while (endIndex < inputText.length() && endIndex < targetText.length() && inputText.charAt(endIndex) == targetText.charAt(endIndex)) {
                        endIndex++;
                    }
                    s.setSpan(new ForegroundColorSpan(Color.GREEN), 0, endIndex, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    if (endIndex < s.length()) {
                        ForegroundColorSpan[] spans = s.getSpans(endIndex, s.length(), ForegroundColorSpan.class);
                        for (ForegroundColorSpan span : spans) {
                            s.removeSpan(span);
                        }
                    }
                }
            });
        
        cdown = new CountDownTimer(1, 1) {
            @Override
            public void onTick(long p1) {
            }
            @Override
            public void onFinish() {
                ipush(pie()+"");
                if (!running) cancel();
                else start();
            }
        };
            
        OnClickListener ear = new OnClickListener() {
            @Override
            public void onClick(View p1) {
                switch (p1.getId()) {
                    case R.id.start:
                        running = true;
                        stop.setEnabled(true);
                        start.setEnabled(false);
                        hold.setEnabled(false);
                        Xt.setFocusable(false);
                        // start mass update
                        cdown.start();
                        break;
                    case R.id.stop:
                        running = false;
                        stop.setEnabled(false);
                        start.setEnabled(true);
                        hold.setEnabled(true);
                        Xt.setFocusable(true);
                        break;
                    case R.id.clear:
                        logbox.setText("");
                }
            }
        };
        
        hold.setOnTouchListener(new View.OnTouchListener() {
                private Handler handler = new Handler();
                private boolean isLongClick = false;

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            isLongClick = true;
                            handler.postDelayed(longClickRunnable, 500);
                            break;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            handler.removeCallbacks(longClickRunnable);
                            if (isLongClick) {
                                ipush(pie()+"");
                            }
                            isLongClick = false;
                            break;
                    }
                    return false;
                }

                private Runnable longClickRunnable = new Runnable() {
                    @Override
                    public void run() {
                        if (isLongClick) {
                            ipush(pie()+"");
                            handler.postDelayed(this, 1);
                        }
                    }
                };
            });
        
        Button[] btns = {hold, start, stop, clear};
        for (Button btn : btns) {
            btn.setOnClickListener(ear);
        }
    }
    
    public void ipush(String topush) {
        log = "\n" + logbox.getText();
        logbox.setText(topush + (stack.isChecked() ? log : ""));
    }
    
    public double pie() {
        String t = "";
        t = Xt.getText().toString();
        if (t.isEmpty()) X = 1;
        else X = Integer.parseInt(t);
        
        t = onx1.getText().toString();
        if (t.isEmpty()) onx1_v = 4;
        else onx1_v = Integer.parseInt(t);
        
        t = onx2.getText().toString();
        if (t.isEmpty()) onx2_v = 4;
        else onx2_v = Integer.parseInt(t);
        
        t = xp.getText().toString();
        if (t.isEmpty()) xp_v = 2;
        else xp_v = Integer.parseInt(t);
        
        t = px.getText().toString();
        if (t.isEmpty()) px_v = 4;
        else px_v = Integer.parseInt(t);
        
        pi += (onx1_v/X) - (onx2_v/(X+xp_v));
        X += px_v;
        Xt.setText(X+"");
        return pi;
    }
}
