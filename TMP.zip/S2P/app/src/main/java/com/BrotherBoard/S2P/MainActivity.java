package com.BrotherBoard.S2P;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.transition.Fade;
import android.transition.TransitionManager;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.BrotherBoard.S2P.MainActivity;

public class MainActivity extends Activity {
    
    private boolean doubleBackToExitPressedOnce = false;
    
    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }
        this.doubleBackToExitPressedOnce = true;
        toast("Press back again to go bye bye");
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    doubleBackToExitPressedOnce=false;                       
                }
            }, 2000);
    }
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        wasCreated();
    }
    
    public void wasCreated() {
        String a = getVar("isLight");
        if (a.contains("1")) {
            setTheme(android.R.style.Theme_DeviceDefault_Light_NoActionBar);
        }
        setContentView(R.layout.loading);
        load();
    }
    
    public void load() {
        final ProgressBar poggers = findViewById(R.id.poggers);
        new CountDownTimer(3000, 10) {
            @Override
            public void onTick(long p1) {
                int prog = poggers.getProgress();
                poggers.setProgress(prog + 1);
                ((TextView) findViewById(R.id.loadingStatus)).setText((prog  > 80) ? "Starting mainVoid" : ((prog > 30) ? "Reading environment variables" : "Triggering wasCreated"));
            }
            @Override
            public void onFinish() {
                fadeIn();
                mainVoid();
            }
        }.start();
    }
    
    public void storeVar(String varName, String varValue) {
        SharedPreferences VARS = getSharedPreferences("S2P_VARS", MODE_PRIVATE);
        SharedPreferences.Editor editShare = VARS.edit();
        editShare.putString(varName, varValue);
        editShare.apply();
    }
    
    public void nukeVar(String varName) {
        SharedPreferences VARS = getSharedPreferences("S2P_VARS", MODE_PRIVATE);
        SharedPreferences.Editor editShare = VARS.edit();
        editShare.putString(varName, "");
        editShare.apply();
    }
    
    public String getVar(String varName) {
        SharedPreferences VARS = getSharedPreferences("S2P_VARS", MODE_PRIVATE);
        return VARS.getString(varName, varName);
    }
    
    public void fadeIn() {
        ViewGroup rootView = findViewById(android.R.id.content);
        TransitionManager.beginDelayedTransition(rootView, new Fade(Fade.IN).setDuration(500));
    }
    
    public void fadeOut() {
        ViewGroup rootView = findViewById(android.R.id.content);
        TransitionManager.beginDelayedTransition(rootView, new Fade(Fade.OUT).setDuration(500));
    }
    
    public void toast(String toToast) {
        Toast.makeText(MainActivity.this, toToast, Toast.LENGTH_LONG).show();
    }
    
    public void mainVoid() {
        int dpi = getResources().getDisplayMetrics().densityDpi;
        if( dpi < 340 ) {
            setContentView(R.layout.activity_main);
        } else {
            setContentView(R.layout.main_mdpi);
        }
    }
}
