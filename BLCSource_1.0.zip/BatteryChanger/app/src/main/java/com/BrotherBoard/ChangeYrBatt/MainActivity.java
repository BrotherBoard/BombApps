package com.BrotherBoard.ChangeYrBatt;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;

import java.lang.Process;
import java.math.*;
import android.transition.*;
import android.widget.CompoundButton.*;
import android.text.*;
import java.util.*;
import java.sql.Struct;
import java.util.function.Function;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        final EditText percent = findViewById(R.id.prcnt);
        final TextView logs = findViewById(R.id.tips);
        final Button apply = findViewById(R.id.apply);
        final Button reset = findViewById(R.id.reset);
        apply.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View p1) {
                    String num = percent.getText().toString();
                    
                          try {
                              Runtime.getRuntime().exec("su -c dumpsys battery set level "+num);
                              logs.setText("Percentage changed");
                    } catch (IOException e) {}
                }
        });
        
        reset.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View p1) {
                    try {
                        Runtime.getRuntime().exec("su -c dumpsys battery reset level");
                        logs.setText("Resetted successfully");
                    } catch (IOException e) {}
                }
            });
    }
}
