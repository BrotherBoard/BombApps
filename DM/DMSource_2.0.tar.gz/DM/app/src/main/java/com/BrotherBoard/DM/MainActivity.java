package com.BrotherBoard.DM;
 
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.transition.Fade;
import android.transition.TransitionManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
String n = "\n";
String titlea = "";
String msg = "";
String pbtn = "";
String nbtn = "";
Boolean bool = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        justCreated();
    }
    public void justCreated() {
        up();
        final EditText title = findViewById(R.id.title);
        final EditText message = findViewById(R.id.msg);
        final EditText positive = findViewById(R.id.pbtn);
        final EditText negative = findViewById(R.id.nbtn);
        final CheckBox cancelable = findViewById(R.id.bool);
        final AlertDialog.Builder dial = new AlertDialog.Builder(MainActivity.this);
        findViewById(R.id.make).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {
                dial.setTitle(title.getText().toString());
                dial.setMessage(message.getText().toString());
                dial.setPositiveButton(positive.getText().toString(), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface p1, int p2) {
                        }
                });
                dial.setNegativeButton(negative.getText().toString(), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface p1, int p2) {
                        }
                    });
                dial.setCancelable((!(negative.getText()+"").isEmpty() || !(positive.getText()+"").isEmpty()) ? cancelable.isChecked() : true);
                bool = cancelable.isChecked();
                dial.show();
            }
        });
        
        int edits[] = {R.id.pbtn, R.id.nbtn, R.id.title, R.id.msg};
        for (int id : edits) {
            eye(id);
        }
        cancelable.setOnCheckedChangeListener(new OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    bool = p2;
                    up();
                }
        });
    }
    
    public void eye(final int id) {
        TextWatcher eyee = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {
            }
            @Override
            public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {
                switch (id) {
                    case R.id.title:
                        titlea = p1+"";
                        break;
                    case R.id.msg:
                        msg = p1+"";
                        break;
                    case R.id.pbtn:
                        pbtn = p1 +"";
                        break;
                    case R.id.nbtn:
                        nbtn = p1+"";
                        break;
                }
                up();
            }
            @Override
            public void afterTextChanged(Editable p1) {
            }        
        };
        EditText toWatch = findViewById(id);
        toWatch.addTextChangedListener(eyee);
    }
    public void up() {
        int cElem[] = {R.id.pbtnCode, R.id.nbtnCode, R.id.titleCode, R.id.msgCode, R.id.boolCode};
        for (int i : cElem) {
            String toSet = (i==cElem[0]) ? pbtn : (i==cElem[1]) ? nbtn :
                           (i==cElem[2]) ? titlea : (i==cElem[3]) ? msg : bool+"";
            ((TextView) findViewById(i)).setText("\""+toSet+"\"");
        }
    }
}
