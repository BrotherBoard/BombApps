package com.BrotherBoard.FMD;

import android.R;
import android.widget.Toast;
import android.app.Activity;
import android.os.Bundle;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends Activity 
{
    public String exec(String cmd) {
        String out = "";
        try {
            Process in = Runtime.getRuntime().exec(cmd);
            BufferedReader reader = new BufferedReader(new InputStreamReader(in.getInputStream()));
            out=reader.readLine();
        } catch (IOException e) {}
        return out;
    }

    public void makeToast(String toToast) {
        Toast.makeText(MainActivity.this, toToast, Toast.LENGTH_SHORT).show();
    }
    
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        String lmao = exec("su -c wm density | grep ride | grep -o 338");
        if (lmao == null) { exec("su -c wm density 338"); }
        makeToast("FMD: Triggred");
        finishAndRemoveTask();
    }
}
