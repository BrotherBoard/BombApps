package com.BrotherBoard.DBB;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.transition.Fade;
import android.transition.TransitionManager;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import com.BrotherBoard.DBB.MainActivity;
import com.BrotherBoard.DBB.R;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import android.view.View.OnLongClickListener;

public class MainActivity extends Activity {
    private String version = "v15.1 beta";
    
    int niceGreen = Color.rgb(0,0.5f,0);
    int lmao = 1;
    int lowestDc_int = 100;
    String suspected_divisor = "NONE";
    boolean skipHi = false;
    int modesCdownInt = 2400;
    final int[] clicks = {
        R.id.iGetIt, R.id.already,
        R.id.mybatt_pre2, R.id.fish_pre2,
        R.id.skip_pre2, R.id.low_pre2
    };
    
    private String real_current;
    private int localUp = 1;
    private float prcnt;
    private EditText logbox;
    private int dvisor;
    private Button onion_edit;
    
    private BroadcastReceiver updateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if ("com.BrotherBoard.DBB.UPDATE_ACTION".equals(intent.getAction())) {
                update();
            }
        }
    };
    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Press back again to go bye bye", Toast.LENGTH_SHORT).show();

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    doubleBackToExitPressedOnce=false;                       
                }
            }, 2000);
    }
    
    WindowManager windowManager;
    TextView onion;
    
    @SuppressLint("ClickableViewAccessibility")
    private void startPowerOverlay(){
        // Starts the button overlay.
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        onion = new TextView(this);
        onion.setText("100.0%");
        
        onion.setBackgroundColor(Color.CYAN);
        onion.setTextColor(Color.BLACK);
        onion.setVisibility(View.INVISIBLE);
        onion.setGravity(Gravity.CENTER_VERTICAL);

        int LAYOUT_FLAG;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // APPLICATION_OVERLAY FOR ANDROID 26+ AS THE PREVIOUS VERSION RAISES ERRORS
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            // FOR PREVIOUS VERSIONS USE TYPE_PHONE AS THE NEW VERSION IS NOT SUPPORTED
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;
        }

        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            LAYOUT_FLAG,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 100;
        //params.height = onion.getHeight();
        //params.width = onion.getWidth();

        windowManager.addView(onion, params);
        
  
        onion.setOnTouchListener(new View.OnTouchListener() {
                private int initialX;
                private int initialY;
                private float initialTouchX;
                private float initialTouchY;
                private long latestPressTime = 0;
                

                @Override public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            update();
                            // Save current x/y
                            initialX = params.x;
                            initialY = params.y;
                            initialTouchX = event.getRawX();
                            initialTouchY = event.getRawY();
                            // Check for double clicks. 
                            if (latestPressTime == 0 || latestPressTime + 500 < System.currentTimeMillis()) {
                                latestPressTime = System.currentTimeMillis();
                            } else {
                                // Doubleclicked. Do any action you'd like
                            }
                            return true;
                        case MotionEvent.ACTION_UP:
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            params.x = initialX + (int) (event.getRawX() - initialTouchX);
                            params.y = initialY + (int) (event.getRawY() - initialTouchY);
                            windowManager.updateViewLayout(onion, params);
                            return true;
                    }
                    return false;
                }
            });
    }
    
    private int redValue = 140;
    private int greenValue = 90;
    private int blueValue = 200;
    
    private int redValue2 = 230;
    private int greenValue2 = 110;
    private int blueValue2 = 150;
    
    private int sizeValue = 20;
    private int traValue = 60;
    
    private TextView colorPreview;
    private LinearLayout layout;
    
    public void openColorPickerDialog(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Color Picker");

        layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 50, 50, 50);

        // Add color preview
        colorPreview = new TextView(this);
        colorPreview.setBackgroundColor(Color.rgb(redValue, greenValue, blueValue));
        colorPreview.setTextColor(Color.rgb(redValue2, greenValue2, blueValue2));
        colorPreview.setLayoutParams(new ViewGroup.LayoutParams(
                                         ViewGroup.LayoutParams.WRAP_CONTENT,
                                         ViewGroup.LayoutParams.WRAP_CONTENT));
        colorPreview.setGravity(Gravity.CENTER);
        colorPreview.setTextSize(sizeValue);
        colorPreview.setAlpha(traValue / 100.0f);
        colorPreview.setText("100.0%");
        layout.addView(colorPreview);
        //layout.addView(onion);

        final TextView redTextView = new TextView(this);
        redTextView.setText("Red Background:");
        layout.addView(redTextView);

        final SeekBar redSeekBar = new SeekBar(this);
        redSeekBar.setMax(255);
        redSeekBar.setProgress(redValue);
        redSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    redValue = progress;
                    updateColorPreview();
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {}

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        layout.addView(redSeekBar);

        final TextView greenTextView = new TextView(this);
        greenTextView.setText("Green Background:");
        layout.addView(greenTextView);

        final SeekBar greenSeekBar = new SeekBar(this);
        greenSeekBar.setMax(255);
        greenSeekBar.setProgress(greenValue);
        greenSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    greenValue = progress;
                    updateColorPreview();
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {}

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        layout.addView(greenSeekBar);

        final TextView blueTextView = new TextView(this);
        blueTextView.setText("Blue Background:");
        layout.addView(blueTextView);

        final SeekBar blueSeekBar = new SeekBar(this);
        blueSeekBar.setMax(255);
        blueSeekBar.setProgress(blueValue);
        blueSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    blueValue = progress;
                    updateColorPreview();
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {}

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        layout.addView(blueSeekBar);
      
        
        final TextView redTextView2 = new TextView(this);
        redTextView2.setText("Red Text:");
        redTextView2.setPadding(0, 40, 0, 0);
        layout.addView(redTextView2);

        final SeekBar redSeekBar2 = new SeekBar(this);
        redSeekBar2.setMax(255);
        redSeekBar2.setProgress(redValue2);
        redSeekBar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    redValue2 = progress;
                    updateColorPreview();
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {}

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        layout.addView(redSeekBar2);

        final TextView greenTextView2 = new TextView(this);
        greenTextView2.setText("Green Text:");
        layout.addView(greenTextView2);

        final SeekBar greenSeekBar2 = new SeekBar(this);
        greenSeekBar2.setMax(255);
        greenSeekBar2.setProgress(greenValue2);
        greenSeekBar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    greenValue2 = progress;
                    updateColorPreview();
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {}

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        layout.addView(greenSeekBar2);

        final TextView blueTextView2 = new TextView(this);
        blueTextView2.setText("Blue Text:");
        layout.addView(blueTextView2);

        final SeekBar blueSeekBar2 = new SeekBar(this);
        blueSeekBar2.setMax(255);
        blueSeekBar2.setProgress(blueValue2);
        blueSeekBar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    blueValue2 = progress;
                    updateColorPreview();
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {}

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        layout.addView(blueSeekBar2);
        
        final TextView sizeTextView = new TextView(this);
        sizeTextView.setText("Size:");
        sizeTextView.setPadding(0, 40, 0, 0);
        layout.addView(sizeTextView);

        final SeekBar sizeSeekBar = new SeekBar(this);
        sizeSeekBar.setMax(100);
        sizeSeekBar.setProgress(sizeValue);
        sizeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    sizeValue = progress;
                    updateColorPreview();
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {}

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        layout.addView(sizeSeekBar);
        
        final TextView traTextView = new TextView(this);
        traTextView.setText("Transparency:");
        layout.addView(traTextView);

        final SeekBar traSeekBar = new SeekBar(this);
        traSeekBar.setMax(100);
        traSeekBar.setProgress(traValue);
        traSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    traValue = progress;
                    updateColorPreview();
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {}

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        traSeekBar.setPadding(sizeSeekBar.getPaddingLeft(), 0, sizeSeekBar.getPaddingRight(), 40);
        layout.addView(traSeekBar);
        
        Button randum = new Button(this);
        
        randum.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {
                Random L= new Random();
                blueValue = L.nextInt(255 + 1);
                blueSeekBar.setProgress(blueValue);
                redValue = L.nextInt(255 + 1);
                redSeekBar.setProgress(redValue);
                greenValue = L.nextInt(255 + 1);
                greenSeekBar.setProgress(greenValue);
                
                blueValue2 = L.nextInt(255 + 1);
                blueSeekBar2.setProgress(blueValue2);
                redValue2 = L.nextInt(255 + 1);
                redSeekBar2.setProgress(redValue2);
                greenValue2 = L.nextInt(255 + 1);
                greenSeekBar2.setProgress(greenValue2);
            }
        });
        
        randum.setText("Randomize!");
        layout.addView(randum);

        builder.setView(layout);

        builder.setPositiveButton("Apply", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    onion.setBackgroundColor(Color.rgb(redValue, greenValue, blueValue));
                    onion.setTextColor(Color.rgb(redValue2, greenValue2, blueValue2));
                    onion.setTextSize(sizeValue);
                    onion.setAlpha(traValue / 100.0f);
                }
            });
            
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    
                }
            });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void updateColorPreview() {
        if (colorPreview != null) {
            colorPreview.setBackgroundColor(Color.rgb(redValue, greenValue, blueValue));
            colorPreview.setTextColor(Color.rgb(redValue2, greenValue2, blueValue2));
            colorPreview.setTextSize(sizeValue);
            colorPreview.setAlpha(traValue / 100.0f);
        }
    }
    
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)){
            CharSequence text = "Please grant the access to the application.";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(this, text, duration);
            toast.show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.fromParts("package", getPackageName(), null)));
        } else {
            startPowerOverlay();
        }
        IntentFilter filter = new IntentFilter("com.BrotherBoard.DBB.UPDATE_ACTION");
        registerReceiver(updateReceiver, filter);
        wasCreated();
        colorPreview = new TextView(this);
        colorPreview.setPadding(20, 20, 20, 20);
        colorPreview.setBackgroundColor(Color.rgb(redValue, greenValue, blueValue));
        updateColorPreview();
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Unregister the broadcast receiver
        if (onion != null)
            windowManager.removeView(onion);
        unregisterReceiver(updateReceiver);
    }
    
    public void wasCreated() {
        String a = getVar("isLight");
        if (a.contains("1")) {
            setTheme(android.R.style.Theme_DeviceDefault_Light_NoActionBar);
        }
        setContentView(R.layout.loading);
        TextView ver = findViewById(R.id.version);
        ver.setText(version);
        lmao=1;
        if(skipHi) modes();
        else load();
    }
    
    public void load() {
        final ProgressBar poggers = findViewById(R.id.poggers);
        new CountDownTimer(3000, 10) {
            @Override
            public void onTick(long p1) {
                int prog = poggers.getProgress();
                poggers.setProgress(prog + 1);
                ((TextView) findViewById(R.id.loadingStatus)).setText((prog  > 80) ? "Starting mainVoid" : ((prog > 30) ? "Reading environment variables" : "Triggering wasCreated"));
            }
            @Override
            public void onFinish() {
                fadeIn();
                if(getVar("notFirst").isEmpty() || getVar("notFirst").equals("notFirst")) {
                    hi();
                } else {
                    mainVoid();
                }
            }
        }.start();
    }
    
    public void setPreResult(int resultId, String toSet) {
        TextView[] result = {findViewById(R.id.result1_pre3), findViewById(R.id.result2_pre3), findViewById(R.id.result3_pre3)};
        try{
            result[resultId].setEnabled(true);
            result[resultId].setText(toSet);
        } catch (ArrayIndexOutOfBoundsException e) {
            result[Integer.parseInt(toSet)].setTextColor(niceGreen);
        }
    }

    public void capture1() {
        final TextView rep1 = findViewById(R.id.rep1);
        rep1.setVisibility(View.VISIBLE);
        setPreResult(0, getVar("currentNow")+" is still "+getCounter()+", attempt: ");
        CountDownTimer cdawn = new CountDownTimer(2000, 1000) {
            public void onTick(long p1) {
            }
            public void onFinish() {
                rep1.setText(Integer.parseInt(rep1.getText().toString()) + 1 +"");
                capture1();
            }
        };
        if(getVar("currentNow").equals(""+getCounter())) {
            cdawn.start();
        } else {
            cdawn.cancel();
            toast("Capture 1 is done, please check result");
            int result1 = (Integer.parseInt(getVar("currentNow")) - getCounter());
            storeVar("result1", result1+"");
            setPreResult(0, "done, result: "+result1+", attempt: ");
            setPreResult(70, "0");
            storeVar("currentNow", ""+getCounter());
            findViewById(R.id.capture2_pre3).setEnabled(true);
            findViewById(R.id.tripleBack).setEnabled(true);
        }
    }

    public void capture2() {
        final TextView rep2 = findViewById(R.id.rep2);
        rep2.setVisibility(View.VISIBLE);
        CountDownTimer cdawn = new CountDownTimer(2000, 1000) {
            public void onTick(long p1) {
            }
            public void onFinish() {
                setPreResult(1, getVar("currentNow")+" is still "+getCounter()+", attempt: ");
                rep2.setText(Integer.parseInt(rep2.getText().toString()) + 1 +"");
                capture2();
            }
        };
        if(getVar("currentNow").equals(""+getCounter())) {
            cdawn.start();
        } else {
            cdawn.cancel();
            toast("Capture 2 is done, please check result");
            int result2 = (Integer.parseInt(getVar("currentNow")) - getCounter());
            storeVar("result2", result2+"");
            setPreResult(1, "done, result: "+result2+", attempt: ");
            setPreResult(70, "1");
            storeVar("currentNow", ""+getCounter());
            findViewById(R.id.capture3_pre3).setEnabled(true);
            findViewById(R.id.tripleBack).setEnabled(true);
        }
    }

    public void capture3() {
        final TextView rep3 = findViewById(R.id.rep3);
        rep3.setVisibility(View.VISIBLE);
        CountDownTimer cdawn = new CountDownTimer(2000, 1000) {
            public void onTick(long p1) {
            }
            public void onFinish() {
                setPreResult(2, getVar("currentNow")+" is still "+getCounter()+", attempt: ");
                rep3.setText(Integer.parseInt(rep3.getText().toString()) + 1 +"");
                capture3();
            }
        };
        if(getVar("currentNow").equals(""+getCounter())) {
            cdawn.start();
        } else {
            cdawn.cancel();
            toast("Capture 3 is done, please check result");
            int result3 = (Integer.parseInt(getVar("currentNow")) - getCounter());
            setPreResult(2, "done, result: "+result3+", attempt: ");
            setPreResult(70, "2");
            storeVar("currentNow", ""+getCounter());
            fadeOut();
            int eq1 = 2 * result3;
            int eq2 = Integer.parseInt(getVar("result2")) + Integer.parseInt(getVar("result1"));
            if(eq1 == eq2) {
                findViewById(R.id.tripleBack).setEnabled(true);
                findViewById(R.id.proceed).setVisibility(View.VISIBLE);
                storeVar("notFirst", "My A14 is better than Roynas A90");
                storeVar("Royna", result3+"");
                findViewById(R.id.proceed).setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View p1) {
                            fadeOut();
                            mainVoid();
                        }
                    });
            } else {
                TextView nah = findViewById(R.id.noProceed);
                nah.setTextColor(Color.RED);
                nah.setText("Results don't match, this is a common android bug, if two of them does match, you can take one as a divisor, or just restart the app and try again.\nDebug: 2*"+result3+" ≠ "+getVar("result2") + " + " + getVar("result1"));
                findViewById(R.id.tripleBack).setEnabled(true);
            }
        }
    }
    
    public int getCounter() {
        BatteryManager batteryManager = (BatteryManager) getSystemService(BATTERY_SERVICE);
        return batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
    }
    
    public float getMahLeft() {
        return (Math.round(getMah() * prcnt) / 100.00f);
    }
    
    public double getMah() {
        Object mPowerProfile;
        double batteryCapacity = 0;
        final String POWER_PROFILE_CLASS = "com.android.internal.os.PowerProfile";

        try {
            mPowerProfile = Class.forName(POWER_PROFILE_CLASS)
                .getConstructor(Context.class)
                .newInstance(this);

            batteryCapacity = (double) Class
                .forName(POWER_PROFILE_CLASS)
                .getMethod("getBatteryCapacity")
                .invoke(mPowerProfile);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return batteryCapacity;
    }
    
    public int getBattery() {
        BatteryManager batteryManager = (BatteryManager) getSystemService(BATTERY_SERVICE);
        return batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
    }
    
    public void storeVar(String varName, String varValue) {
        SharedPreferences VARS = getSharedPreferences("DB_VARS", MODE_PRIVATE);
        SharedPreferences.Editor editShare = VARS.edit();
        editShare.putString(varName, varValue);
        editShare.apply();
    }
    
    public void nukeVar(String varName) {
        SharedPreferences VARS = getSharedPreferences("DB_VARS", MODE_PRIVATE);
        SharedPreferences.Editor editShare = VARS.edit();
        editShare.putString(varName, "");
        editShare.apply();
    }
    
    public String getVar(String varName) {
        SharedPreferences VARS = getSharedPreferences("DB_VARS", MODE_PRIVATE);
        return VARS.getString(varName, varName);
    }
    
    public void fadeIn() {
        ViewGroup rootView = findViewById(android.R.id.content);
        TransitionManager.beginDelayedTransition(rootView, new Fade(Fade.IN).setDuration(500));
    }
    
    public void fadeOut() {
        ViewGroup rootView = findViewById(android.R.id.content);
        TransitionManager.beginDelayedTransition(rootView, new Fade(Fade.OUT).setDuration(500));
    }
    
    public void hi() {
        setContentView(R.layout.hi);
        final View[] pre = {findViewById(R.id.pre1), findViewById(R.id.pre2)};
        pre[0].setVisibility(View.VISIBLE);
        new CountDownTimer(4000, 1500) {
            @Override
            public void onTick(long p1) {
                if(p1 < 3000) {
                   fadeIn();
                   pre[1].setVisibility(View.VISIBLE);
                }
            }
            @Override
            public void onFinish() {
                fadeIn();
                modes();
            }
        }.start();
    }
    
    public void modes() {
        setContentView(R.layout.modes);
        if(skipHi) ((TextView) findViewById(R.id.weNeed)).setText("Hello Again!");
        final ProgressBar modesCdownPog = findViewById(R.id.modesCdownPog);
        if(modesCdownInt > 1000) modesCdownPog.setVisibility(View.VISIBLE);
        else modesCdownPog.setVisibility(View.INVISIBLE);
        View.OnClickListener ear = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.fish_pre2:
                        findViewById(clicks[2]).setEnabled(getBattery() == 100);
                        break;
                    case R.id.iGetIt:
                        fadeIn();
                        triple_capture();
                        break;
                    case R.id.already:
                        fadeIn();
                        already();
                        break;
                    case R.id.mybatt_pre2:
                        if(getBattery() == 100) {
                            int Royna = getCounter() / 1000;
                            toast("Nice, your divisor is "+Royna);
                            storeVar("Royna", Royna+"");
                            storeVar("notFirst", "hailYeah");
                            mainVoid();
                            ipush("Set divisor "+Royna+" as default");
                        } else {
                            toast("Liar");
                        }
                        break;
                   case R.id.skip_pre2:
                       storeVar("notFirst", "becauseSkipped");
                       mainVoid();
                       break;
                   case R.id.low_pre2:
                       AlertDialog.Builder lowDialog = new AlertDialog.Builder(MainActivity.this);
                       lowDialog.setTitle("Weak Attempt!");
                       lowDialog.setMessage("Your divisor is suspected to be: "+lowAttempt()+", I am not 100% sure, it will be applied if you skip or enter it manually.");
                       lowDialog.setCancelable(true);
                       lowDialog.show();
                       break;
                }
        }
        };
        for (int b : clicks) {
            findViewById(b).setEnabled(false);
            findViewById(b).setOnClickListener(ear);
            findViewById(b).setVisibility(View.VISIBLE);
        }
        fadeIn();
        CountDownTimer modesCdown = new CountDownTimer(modesCdownInt, 1) {
            public void onTick(long p1) {
                modesCdownPog.setProgress(modesCdownPog.getProgress()+1);
            }
            public void onFinish() {
                for (int b : clicks) {
                    findViewById(b).setEnabled(true);
                }
                modesCdownPog.setVisibility(View.INVISIBLE);
                findViewById(clicks[2]).setEnabled(getBattery() == 100);
                modesCdownInt = 500;
            }
        };
        modesCdown.start();
    }
    
    public void already() {
        setContentView(R.layout.already);
        final Button ikr = findViewById(R.id.ikr);
        ikr.setEnabled(false);
        final EditText txt = findViewById(R.id.divisor_field);
        txt.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {
                }
                @Override
                public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {
                }
                @Override
                public void afterTextChanged(Editable p1) {
                    String text = txt.getText().toString();
                    if(text.equals("")) {
                        ikr.setEnabled(false);
                    } else if(text.startsWith("0")) {
                        ikr.setEnabled(false);
                    } else {
                        ikr.setEnabled(true);
                    }
                }
        });
        ikr.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {
                storeVar("notFirst", "Hi");
                storeVar("Royna", txt.getText().toString());
                mainVoid();
            }
        });
        findViewById(R.id.backAlready).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {
                fadeIn();
                modes();
            }
        });
    }
    
    public void triple_capture() {
        setContentView(R.layout.triple_capture);
        final Button tripleBack = findViewById(R.id.tripleBack);
        final Button[] capture = {findViewById(R.id.capture1_pre3), findViewById(R.id.capture2_pre3), findViewById(R.id.capture3_pre3)};
        capture[1].setEnabled(false);
        capture[2].setEnabled(false);
        OnClickListener capture_ear = new OnClickListener() {
            public void onClick(View p1) {
                tripleBack.setEnabled(false);
                switch (p1.getId()) {
                    case R.id.capture1_pre3:
                        storeVar("currentNow", ""+getCounter());
                        findViewById(R.id.capture1_pre3).setEnabled(false);
                        capture1();
                        break;
                    case R.id.capture2_pre3:
                        storeVar("currentNow", ""+getCounter());
                        findViewById(R.id.capture2_pre3).setEnabled(false);
                        capture2();
                        break;
                    case R.id.capture3_pre3:
                        storeVar("currentNow", ""+getCounter());
                        findViewById(R.id.capture3_pre3).setEnabled(false);
                        capture3();
                        break;
                }
            }
        };
        for (Button btn : capture) {
            btn.setOnClickListener(capture_ear);
        }
        tripleBack.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {
                fadeIn();
                modes();
            }
        });
    }
    
    public void warn(String bigText, String smallText) {
        final ProgressBar pog = findViewById(R.id.poggers);
        final TextView loadMain = findViewById(R.id.loadingText);
        final TextView load = findViewById(R.id.loadingStatus);
        final ProgressBar spin = findViewById(R.id.spin);
        final Button tryAgain = findViewById(R.id.tryAgain);
        final ProgressBar poggers = findViewById(R.id.poggers);
        loadMain.setText(bigText);
        load.setText(smallText);
        load.setTextColor(Color.RED);
        pog.setAlpha(0.5f);
        spin.setVisibility(View.GONE);
        tryAgain.setVisibility(View.VISIBLE);
        tryAgain.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    tryAgain.setVisibility(View.INVISIBLE);
                    spin.setVisibility(View.VISIBLE);
                    load.setTextColor(Color.GRAY);
                    pog.setAlpha(1.0f);
                    poggers.setProgress(0);
                    loadMain.setText("Initializing");
                    load();
                }
            });
    }
    
    // static strings
    String n = "\n";
    
    // main code
    // methods
    public void toast(String toToast) {
        Toast.makeText(MainActivity.this, toToast, Toast.LENGTH_LONG).show();
    }

    public void more(){
        findViewById(R.id.more).setEnabled(false);
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        final List items = Arrays.asList("Clear logs", "Dump battery to logs", "Send \"lmao\" to logs", "Close app", "Store variable", "Nuke variable", "Get variable", "Light Mode", "Dark Mode", "Small Layout", "Wide Layout");
        final EditText logbox = findViewById(R.id.logbox);
        builder.setTitle("More options");
        ListView listView = new ListView(MainActivity.this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, items);
        listView.setAdapter(adapter);
        builder.setView(listView);
        final AlertDialog dialog = builder.create();
        dialog.show();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4) {
                    switch (p3) {
                        case 0:
                            toast("cleared logs");
                            logbox.setText("");
                            TextView lastCommit = findViewById(R.id.lastCommit);
                            lastCommit.setText("last report");
                            break;
                        case 1:
                            ipush(getBattery()+" || "+getVar("Royna"));
                            break;
                        case 2:
                            ipush("lmao");
                            break;
                        case 3:
                            finishAfterTransition();
                            break;
                        case 4:
                            AlertDialog.Builder SV = new AlertDialog.Builder(MainActivity.this);
                            SV.setTitle("Nuke Variable");
                            SV.setMessage("Enter variable name and value below");
                            final EditText SVT1 = new EditText(MainActivity.this);
                            SVT1.setHint("name");
                            final EditText SVT2 = new EditText(MainActivity.this);
                            SVT2.setHint("value");
                            LinearLayout SVT = new LinearLayout(MainActivity.this);
                            SVT.setGravity(Gravity.CENTER);
                            SVT.addView(SVT1);
                            SVT.addView(SVT2);
                            SV.setView(SVT);
                            SV.setPositiveButton("Store", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface p1, int p2) {
                                        ipush("Store Variable: stored "+SVT1.getText().toString()+" with value "+SVT2.getText().toString());
                                        storeVar(SVT1.getText().toString(), SVT2.getText().toString());
                                    }
                                });
                            SV.create();
                            SV.show();
                            break;
                        case 5:
                            AlertDialog.Builder NV = new AlertDialog.Builder(MainActivity.this);
                            NV.setTitle("Nuke Variable");
                            NV.setMessage("Enter variable name below, ex. Royna, lmao, notFirst, currentNow, result1, result2, result3, customRoyna, testVar");
                            final EditText NVT = new EditText(MainActivity.this);
                            NV.setView(NVT);
                            NV.setPositiveButton("Nuke", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface p1, int p2) {
                                        ipush("Nuke Variable: nuked "+NVT.getText().toString());
                                        nukeVar(NVT.getText().toString());
                                    }
                                });
                            NV.create();
                            NV.show();
                            break;
                        case 6:
                            AlertDialog.Builder GV = new AlertDialog.Builder(MainActivity.this);
                            GV.setTitle("Get Variable");
                            GV.setMessage("Enter variable name below, ex. Royna, lmao, notFirst, currentNow, result1, result2, result3, customRoyna, testVar");
                            final EditText GVT = new EditText(MainActivity.this);
                            GV.setView(GVT);
                            GV.setPositiveButton("Get", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface p1, int p2) {
                                        ipush("Get Variable: "+getVar(GVT.getText().toString()));
                                    }
                            });
                            GV.create();
                            GV.show();
                            break;
                        case 7:
                            // Light Mode
                            //setTheme(android.R.style.Theme_DeviceDefault_Light_NoActionBar);
                            storeVar("isLight", "1");
                            toast("Average light mode enjoyer, reopen app eta");
                            finishAfterTransition();
                            break;
                        case 8:
                            // Dark Mode
                            //setTheme(android.R.style.Theme_DeviceDefault_NoActionBar);
                            storeVar("isLight", "0");
                            toast("Dark mode applied, reopen app");
                            finishAfterTransition();
                            break;
                        case 9:
                            storeVar("forceWide", "0");
                            toast("Forced small mode, open app again lil bro");
                            finishAfterTransition();
                            break;
                        case 10:
                            storeVar("forceWide", "1");
                            toast("Forced wide mode, open app again lol");
                            finishAfterTransition();
                            break;
                    }
                   dialog.dismiss();
                }
            });
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface p1) {
                    findViewById(R.id.more).setEnabled(true);
                    Switches(true);
                }
        });
    }

    public void ipush(String toPush) {
        String a = (logbox.getText().toString().isEmpty()) ? "" : "\n";
        //logbox.setText(toPush + a + logbox.getText().toString());
        logbox.append(a + toPush);
        TextView lastCommit = findViewById(R.id.lastCommit);
        lastCommit.setText(toPush);
    }

    public void blenk() {
        Switches(false);
        new CountDownTimer(300, 300) {
            @Override
            public void onTick(long p1) {}
            @Override
            public void onFinish() {
                Switches(true);
            }
        }.start();
    }

    public void safe() {
        TextView dialogText = new TextView(this);
        dialogText.setText("Are you sure you want to capture the divisor again? this will revert app like it was on first launch, in order to run the capture wizard\n\nPress OK to continue");
        CheckBox dialogBox = new CheckBox(this);
        dialogBox.setChecked(skipHi);
        dialogBox.setText("Quick Mode");
        dialogBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton p1, boolean p2) {
                skipHi = p2;
            }
        });
        LinearLayout dialogLayout = new LinearLayout(this);
        dialogLayout.addView(dialogText);
        dialogLayout.addView(dialogBox);
        dialogLayout.setOrientation(1);
        final AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
            .setTitle("Capture divisor") .setCancelable(false)
            .setView(dialogLayout)
            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    nukeVar("notFirst");
                    fadeOut();
                    wasCreated();
                }
            })
            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    toast("Phew.");
                }
            })
            .create();
        dialog.show();
    }

    // for switches
    public void Switches(boolean enable) {
        int[] switches = {
            (R.id.set_box),
            (R.id.auto_switch),
            (R.id.custom_switch),
            (R.id.refresh_box),
            (R.id.more),
            (R.id.update_btn),
            (R.id.capture_btn),
            (R.id.test_btn),
            (R.id.tip_btn),
            (R.id.notify_switch)
        };
        for (int v : switches) {
            findViewById(v).setEnabled(enable);
        }
    }
    
    public void busy(boolean show) {
        findViewById(R.id.busy).setVisibility((show) ? View.VISIBLE : View.INVISIBLE);
    }
    
    public int iAmFull() {
        int Royna = Integer.parseInt(getVar("Royna"));
        if(getBattery() == 100) {
            Royna = getCounter() / 1000;
            toast("Nice, your divisor is "+Royna);
            storeVar("Royna", Royna+"");
        } else {
            toast("Liar");
        }
        return Royna;
    }
    
    public String updateRoyna() {
        EditText box = findViewById(R.id.set_box);
        Switch custom = findViewById(R.id.custom_switch);
        String Royna;
        if(custom.isChecked()) {
            Royna = box.getText().toString();
            String lowAttempt = lowAttempt();
            if(Royna.isEmpty()) {Royna = lowAttempt; box.setHint(lowAttempt);}
        } else {
            Royna=getVar("Royna");
        }
        storeVar("customRoyna", Royna);
        return Royna;
    }
    
    public void ping(String title, String toPing) {
        alex.ping(this, title, toPing, Integer.parseInt(real_current.split("%")[0].replace(".", "")));
    }
    
    public String getArt() {
        String art = "";
        String on = "■";
        String off = "□";
        
        String prcnt = real_current.split("%")[0];
        int idk = Integer.parseInt(prcnt.replace(".", ""));
        int n = 0;
        while (n < idk / 2) {
            art += on;
            n++;
        }
        int p = n;
        while (p < 500) {
            art += off;
            p++;
        }
        art = "Highlighted: " + prcnt.replace(".", "") + "box / 1000box\n" + art;
        return art;
    }
    
    public void update() {
        isFull();
        TextView current = findViewById(R.id.current);
        TextView error = findViewById(R.id.errorView);
        error.setTextColor(Color.RED);
        dvisor = Integer.parseInt(updateRoyna());
        prcnt = (getCounter() / dvisor) / 10.00f;
        float batt = getBattery() + 0.00f;
        String tip = (prcnt - batt) >= 1 ? "("+(prcnt - (prcnt - batt) + 0.90f)+"%) " : "";
        real_current = (prcnt+"% "+tip);
        current.setText(real_current);
        ((TextView)findViewById(R.id.currentmah)).setText(getMahLeft() + " mah / " + getMah() + " mah");
        String lol = "";
        String art = "";
        if(((Switch) findViewById(R.id.notify_switch)).isChecked()) {
            if (((Switch)findViewById(R.id.auto_switch)).isChecked()) {
                String interval = ((EditText)findViewById(R.id.refresh_box)).getText().toString();
                lol = "| "+(interval.isEmpty() ? "5s " : interval+"s ");
            }
            art = getArt();
            String tips = "Charge Counter: " + getCounter() + "mph / " + (dvisor * 1000) + "mph";
            String mah = getMahLeft() + "mah / " + getMah() + "mah\n";
            tips += "\nCurrent Mah: " + mah;
            tips += "Divisor: " + dvisor + "\n";
            ping(current.getText()+lol+"| ["+localUp+"]", tips + art);
        }
        error.setText((prcnt > 100) ? "divisor is too small" : (prcnt > (batt + 2)) ? "invalid percentage, divisor needs to be bigger" : (prcnt < (batt - 1)) ? "invalid percentage, divisor needs to be smaller" : "");
        ipush("UP: "+prcnt+"% ["+lmao+"]"+tip);
        onion.setText(prcnt+"%"+tip);
        ++lmao;
        localUp = lmao;
    }
    
    public void autoUpdate() {
        EditText refreshBox = findViewById(R.id.refresh_box);
        String refreshText = refreshBox.getText().toString();
        if (refreshText.startsWith("0")) {
            refreshBox.setText("1");
            refreshText = "1";
        }
        final Switch autoSwitch = findViewById(R.id.auto_switch);
        int int1 = (refreshText.isEmpty()) ? 5000 : Integer.parseInt(refreshText) * 1000;
        new CountDownTimer(int1, (int1 / 10)) {
            public void onTick(long p1) {
                if(!autoSwitch.isChecked()) {
                    cancel();
                }
            }
            public void onFinish() {
                update();
                autoUpdate();
            }
        }.start();
    }
    
    public void isFull() {
        findViewById(R.id.full_btn).setEnabled(getBattery() == 100);
    }
    
    public String testDivisor(String dvide, boolean returnEquation) {
        if(dvide.isEmpty()) {
            return "Set a custom divisor first";
        }
        float test = getCounter() / (Integer.parseInt(dvide) * 10.0f);
        String comp = "more than";
        String comp2 = " > ";
        int dc = (test+"").length();
        Float batt = getBattery()+0.0f;
        if ((test > batt) && (test < (batt + 1))) {
            comp = "so close to";
            comp2 = " ~ ";
        } else if(test < batt) {
            comp = "less than";
            comp2 = " < ";
        } else if(test == batt) {
            comp = "equal to";
            comp2 = "=";
        }
        if (lowestDc_int > dc) {
            lowestDc_int = dc;
            suspected_divisor = dvide;
        }
        return (returnEquation) ? "["+dc+"]"+test+comp2+batt+" || dvide"+comp2+dvide :"Test "+test+" is "+comp+" battery "+batt+", divisor may be "+comp+" "+dvide;
    }
    
    public void dialogue(String title, String message, int codeCase) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(title);
        builder.setMessage(message);
        switch (codeCase) {
            case 0:
                builder.setNegativeButton("Dump equations", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface p1, int p2) {
                            AlertDialog.Builder dumpDialog = new AlertDialog.Builder(MainActivity.this);
                            dumpDialog.setTitle("Dump Equations");
                            dumpDialog.setMessage("Enter divisor range to dump");
                            final EditText lel = new EditText(MainActivity.this);
                            lel.setHint("1980");
                            final EditText lel2 = new EditText(MainActivity.this);
                            lel2.setHint("2020");
                            final EditText lel3 = new EditText(MainActivity.this);
                            lel3.setHint("step");
                            LinearLayout lmao = new LinearLayout(MainActivity.this);
                            lmao.addView(lel);
                            TextView b = new TextView(MainActivity.this);
                            b.setText(" >> ");
                            TextView d = new TextView(MainActivity.this);
                            d.setText(" || ");
                            lmao.addView(b);
                            lmao.addView(lel2);
                            lmao.addView(d);
                            lmao.addView(lel3);
                            lmao.setGravity(Gravity.CENTER);
                            dumpDialog.setView(lmao);
                            dumpDialog.setPositiveButton("Start", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface p1, int p2) {
                                        String lel_txt = lel.getText().toString();
                                        String lel2_txt = lel2.getText().toString();
                                        String step1 = lel3.getText().toString();
                                        if(!lel_txt.isEmpty() && !lel2_txt.isEmpty()) {
                                        int range = Integer.parseInt(lel2_txt) - Integer.parseInt(lel_txt);
                                        int repeat = 0;
                                        int step = (step1.isEmpty()) ? 1 : Integer.parseInt(lel3.getText().toString());
                                        while (repeat <= range) {
                                            ipush("Dump "+(repeat+": ")+testDivisor((Integer.parseInt(lel.getText().toString()) + repeat)+"", true));
                                            repeat = repeat + step;
                                        }
                                        }
                                    }
                            });
                            dumpDialog.show();
                        }
                    });
                    break;
            case 1:
                final int between1 = getBetween(1);
                final int between2 = getBetween(2);
                final int uhave = between1 - between2;
                builder.setMessage("Your divisor is between "+between2+" and "+between1+"\nYou have "+uhave+" possibilities.");
                builder.setNegativeButton("Dump", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface p1, int p2) {
                            int repeat = 0;
                            ipush("=== START OF DUMP ===");
                            while (repeat <= uhave) {
                                ipush("Dump "+repeat+": "+testDivisor((between2+repeat)+"", true));
                                ++repeat;
                            }
                            ipush("==== ALMOST DONE ====");
                            ipush("LOWEST DC: "+lowestDc_int);
                            ipush("SUSPECTED DIVISOR: "+suspected_divisor);
                            ipush("==== END OF DUMP ====");
                            lowestDc_int = 100;
                            suspected_divisor= "NONE";
                        }        
                    });
                break;
        }
        builder.setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface p1, int p2) {
                }
            });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    
    public int getBetween(int num) {
        return (num == 1) ? getCounter() / getBattery() / 10 : getCounter() / (getBattery() + 1) / 10;
    }
    
    public String lowAttempt() {
        int b1 = getBetween(1);
        int b2 = getBetween(2);
        int uhave = b1 - b2;
        int repeat = 0;
        while (repeat <= uhave) {
            testDivisor((b2+repeat)+"", true);
            ++repeat;
        }
       return suspected_divisor; 
    }
    
    Switch onion_switch;
    
    public void mainVoid() {
        int dpi = getResources().getDisplayMetrics().densityDpi;
        if( dpi < 340 ) {
            setContentView(R.layout.activity_main);
            logbox = findViewById(R.id.logbox);
            ipush("DPI less than 340 ("+dpi+") applying wide layout");
            if (getVar("forceWide") == "0") {
                ipush("ForceSmallMode by user, applying small layout");
                //setContentView(R.layout.main_mdpi);
            }
        } else {
            setContentView(R.layout.main_mdpi);
            logbox = findViewById(R.id.logbox);
            ipush("DPI more than 340 ("+dpi+") applying small layout");
            if (getVar("forceWide") == "1") {
                ipush("ForceWideMode by user, applying wide layout");
                setContentView(R.layout.activity_main);
            }
        }
        // on start
        isFull();
        final EditText box = findViewById(R.id.set_box);
        onion_switch = findViewById(R.id.onion_switch);
        onion_edit = findViewById(R.id.onion_edit);
        onion_switch.setChecked(getVar("onion") == "true");
        onion.setVisibility(onion_switch.isChecked() ? View.VISIBLE : View.INVISIBLE);
        if(getVar("Royna") == "Royna") toast("Since capture was skipped, applied suspected divisor ("+suspected_divisor+"), this value is not guaranteed.");
       // findViewById(R.id.notify_switch).setEnabled(false);
        
        // elems
        final int[] clickable = {
            (R.id.auto_switch),
            //(R.id.notify_switch),
            (R.id.custom_switch),
            (R.id.more),
            (R.id.capture_btn),
            (R.id.update_btn),
            (R.id.full_btn),
            (R.id.tip_btn),
            (R.id.test_btn)
        };
        
        // onClickListeners
        View.OnClickListener ear = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.auto_switch:
                        autoUpdate();
                        break;
                    case R.id.more:
                        Switches(false);
                        more();
                        break;
                    case R.id.capture_btn:
                        safe();
                        break;
                    case R.id.update_btn:
                        update();
                        break;
                    case R.id.full_btn:
                        iAmFull();
                        box.setText(iAmFull()+"");
                        break;
                    case R.id.tip_btn:
                        dialogue("Instant info", "hmm, I can not calculate it for some reason? this is an error.", 1);
                        break;
                    case R.id.test_btn:
                        dialogue("Test Results", testDivisor(box.getText().toString(), false), 0);
                        break;
                }
            }
        };
        for (int v : clickable) {
            findViewById(v).setOnClickListener(ear);
        }
            final Switch toggle = findViewById(R.id.auto_switch);
            toggle.setOnCheckedChangeListener(new OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton p1, boolean p2) {
                        busy(p2);
                        for (int v : clickable) {
                            findViewById(v).setEnabled(!p2);
                        }
                        toggle.setEnabled(true);
                        }
            });
        onion_switch.setOnCheckedChangeListener(new OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2) {
                    onion.setVisibility(p2 ? View.VISIBLE : View.INVISIBLE);
                    storeVar("onion", p2 + "");
                }
            });
        onion_edit.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {
                openColorPickerDialog(p1);
            }
        });
        ((TextView)findViewById(R.id.nice)).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {
                toast("Made by BrotherBoard!\n@GalaxyA14user on Telegram\ntysm for trying the app");
                
            }
        });
    }
    
}
