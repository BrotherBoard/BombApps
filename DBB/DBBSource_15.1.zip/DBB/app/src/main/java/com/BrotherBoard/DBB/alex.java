package com.BrotherBoard.DBB;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class alex {

    private static final String CHANNEL_ID = "my_channel";
    private static final CharSequence CHANNEL_NAME = "My Channel";
    private static final int NOTIFICATION_ID = 123;

    public static void ping(Context context, String title, String message, int progress) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        // Create a notification channel for Android Oreo and higher
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_LOW);
            notificationManager.createNotificationChannel(channel);
        }

        Notification.Builder builder = new Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.sym_def_app_icon)
            .setContentTitle(title)
            .setOngoing(true)
            .setSound(null) // Set notification sound to nul
            .setProgress(100, progress / 10, false); // Set progress
        // Intent to launch when the notification is clicked
        Intent notificationIntent = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        
        // Change the action to a custom action
        Intent updateIntent = new Intent("com.BrotherBoard.DBB.UPDATE_ACTION");
        PendingIntent updatePendingIntent = PendingIntent.getBroadcast(context, 0, updateIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        builder.addAction(android.R.drawable.ic_popup_sync, "Update now", updatePendingIntent);

        builder.setContentIntent(pendingIntent);
        
        Notification okay = new Notification.BigTextStyle(builder)
            .bigText(message).build();

        // Build and display the notification
        notificationManager.notify(NOTIFICATION_ID, okay);
    }
}

