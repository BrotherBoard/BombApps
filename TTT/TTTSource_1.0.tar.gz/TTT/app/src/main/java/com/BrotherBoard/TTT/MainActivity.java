package com.BrotherBoard.TTT;/*
TTT, an impossible TicTacToe AI by me
Made on Samsung Galaxy A14 (A145F)

import BrotherBoard.t.me */
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends Activity {
    boolean ai[] = {false,
                    false, false, false,
                    false, false, false,
                    false, false, false};
    boolean me[] = {false,
                    false, false, false,
                    false, false, false,
                    false, false, false};
    int grid[] = {R.id.q,
                  R.id.q, R.id.w, R.id.e,
                  R.id.a, R.id.s, R.id.d,
                  R.id.z, R.id.x, R.id.c};
    int corn[] = {1, 3, 7, 9};
    int side[] = {2, 4, 6, 8};
    int turn = 0;
    int lastAi = 0;
    boolean meFirst = false;
    boolean sideKick = false;
    String[] talk = {"I'll go with #, it's your turn",
                     "Picked #, now play fast",
                     "Filled #, I may win",
                     "I played #, end is near",
                     "Ofc #, now u play",
                     "I played #, you still didn't win",
                     "# was played, u mad?",
                     "I picked # since I never make a mistake"};
    int talkCount = 8;
    String[] nice = {"Nice try haha, I did #",
                     "Blocked XD, I played #",
                     "Blocking you is easy, I played #",
                     "I just played #, ruining your dreams of winning",
                     "You were trying to win? lmao I played #",
                     "I filled #, blocking your fail attempt",
                     "I play #... you fail!"};
    int niceCount = 7;
    String flex[] = {"Not surprised that I won... lmao",
                     "That's right, I win",
                     "I'm a winner and you're a- you know the rest",
                     "Another one bites the dust (you)",
                     "I win hahahaha",
                     "Read above, It says impossible to beat"};
    int flexCount = 6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button reset = findViewById(R.id.reset);
        final Switch tick = findViewById(R.id.tick);
        final OnClickListener ear = new OnClickListener() {
            @Override
            public void onClick(View p1) {
                p1.setEnabled(false);
                send(Integer.parseInt(((Button) p1).getHint()+""));
            }
        };
        reset.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {
                turn=0;
                sideKick = new Random().nextBoolean();
                int num=0;
                for (int i : grid) {
                    Button b = findViewById(i);
                    b.setEnabled(true);
                    b.setBackgroundColor(Color.BLACK);
                    b.setAlpha(1);
                    b.setOnClickListener(ear);
                    me[num]=false;
                    ai[num]=false;
                    ++num;
                }
                if(tick.isChecked()){
                    stat("You think you can win by playing first? lmfao");
                } else {
                    int ran = new Random().nextInt(4);
                    play((sideKick) ? corn[ran] : 5);
                }
            }
        });
        reset.callOnClick();
        tick.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View p1) {
                reset.callOnClick();
                meFirst = ((Switch) p1).isChecked();
            }
        });
    }
    // gameIsDone
    public boolean isFinished() {
        for (int i : grid) {
            if (findViewById(i).isEnabled()) {
                return false;
            }
        }
        return true;
    }
    // triggredOnTouch
    public void send(int id) {
        click(id);
        if(meFirst) ++turn;
        if(turn == 1 && !meFirst) {
            turn = 2;
        }
        switch (turn) {
            case 1:
                play(emp(5) ? 5 : corn[new Random().nextInt(4)]);
                break;
            case 2:
                if(ai[5]) {
                    if(hasCorner()) {
                        if(me[id] && me[10-id]) sideAi();
                        else mainAi();
                    } else sideAi();
                } else {
                    mainAi();
                }
                break;
            default:
                mainAi();
                break;
        }
    }
    // talkBox
    public void stat(String a) {
        if(!a.equals("noStat")) ((TextView) findViewById(R.id.stat)).setText(a);
    }
    // finishGame
    public void k() {
        for (int i : grid) {
            findViewById(i).setEnabled(false);
            findViewById(i).setAlpha(0.5f);
        }
        stat("It's A Tie (You Didn't Win Haha)");
    }
    // falseOnEmptyCorners
    public boolean hasCorner() {
        return (!emp(1) || !emp(3) || !emp(7) || !emp(9));
    }
    // The condition voids, they make work easier
    // blockMe
    public boolean c(int a, int b, int c) {
        return play(me[a] && me[b] && emp(c) ? c : me[a] && me[c] && emp(b) ? b : me[c] && me[b] && emp(a) ? a : 10);
    }
    // win
    public boolean c2(int a, int b, int c) {
        return play(ai[a] && ai[b] && emp(c) ? c : ai[a] && ai[c] && emp(b) ? b : ai[c] && ai[b] && emp(a) ? a : 10);
    }
    // hasWon
    public boolean c3(int a, int b, int c) {
        return ai[a] && ai[b] && ai[c];
    }
    // isGonnaWin
    public boolean c4(int a, int b, int c, int e, int f) {
        return ai[a] && ai[b] && emp(c) && ai[a] && ai[e] && emp(f);
    }
    // normalTalk
    public void talk() {
        stat(((TextView)findViewById(R.id.stat)).getText().toString().startsWith("Play Anywhere") || isFinished() ? "noStat" : nice[new Random().nextInt(niceCount)].replace("#", lastAi+""));
    }
    // mainAi here, using condition booleans
    public int mainAi() {
        // tryToWin
        if(c2(1,2,3) || c2(4,5,6) ||
           c2(2,5,8) || c2(1,4,7) ||
           c2(1,5,9) || c2(3,5,7) ||
           c2(9,6,3)) {k(); stat(flex[new Random().nextInt(flexCount)]);}
        else
        // flexPlaying
        if(c(1,2,3) || c(4,5,6) || c(7,8,9) ||
           c(1,4,7) || c(2,5,8) || c(3,6,9) ||
           c(1,5,9) || c(3,5,7)) talk();
        else
        // flexPlaying
        if(ai[5] && (c(1,6,3) || c(7,6,9) || c(9,4,7) ||
                     c(3,4,1) || c(3,8,9) || c(1,8,7))) talk();
        // sideKick
        else if(emp(10-lastAi) && sideKick) {play(10-lastAi);}
        // corn, else side
        else play(emp(1)?1 : emp(3)?3 : emp(7)?7 : emp(9)?9 : sideAi());
        return 10;
    }
    public int sideAi() {
        // twoFourOne
        if(c(2,4,1) || c(2,6,3) ||
           c(4,8,7) || c(6,8,9)){}
        // side, else don't play
        else play(emp(2) ? 2 : emp(4) ? 4 : emp(6) ? 6 : emp(8) ? 8 : 11);
        return 10;
    }
    // isPlayable
    public boolean emp(int which) {
        return (findViewById(grid[which]).isEnabled());
    }
    // triggredOnTouch
    public void click(int which) {
        me[which]=true;
        View v = findViewById(grid[which]);
        v.setEnabled(false);
        v.setBackgroundColor(Color.BLUE);
        if(isFinished() && meFirst) k();
    }
    // ai
    public boolean play(int which) {
        which=(which==0) ? 1 : which;
        lastAi=which;
        if(!meFirst) ++turn;
        if(which < 10) {
            ai[which]=true;
            stat(talk[new Random().nextInt(talkCount)].replace("#", which+""));
            View v = findViewById(grid[which]);
            v.setEnabled(false);
            v.setBackgroundColor(Color.RED);
        }
        if(isFinished()) k();
        // flexAboutToWin
        if(c4(1,3,2,7,4) || c4(9,3,6,7,8) ||
           c4(3,1,2,9,6) || c4(7,9,8,1,4) ||
           c4(3,2,1,5,7) || c4(3,2,1,5,7) ||
           c4(9,6,3,8,7) || c4(7,8,9,6,1) ||
           c4(1,5,9,4,7) || c4(3,5,7,6,9))
           stat("Play Anywhere Coz I Have Two Winning Ways Muahaha");
    return (which < 10);
    }
}
