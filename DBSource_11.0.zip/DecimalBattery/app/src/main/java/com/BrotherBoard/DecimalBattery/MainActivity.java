package com.BrotherBoard.DecimalBattery;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.os.AsyncTask;
import android.os.BatteryManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.view.View.OnClickListener;


public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		Button update = findViewById(R.id.updatebtn);
        Button list = findViewById(R.id.list);
        final Button stop = findViewById(R.id.stawp);
        final Switch notif = findViewById(R.id.notif);
        final TextView yea = findViewById(R.id.yea);
        stop.setEnabled(false);
        list.setEnabled(false);
		chk();
        AD();
        iclear();
        ireset();
        hundred();
        listener();
        
        notif.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, final boolean isChecked) {
                if(isChecked) {
                    yea.setText("yes");
                } else {
                    yea.setText("no");
                }
           }
        });
        
        stop.setOnClickListener(new View.OnClickListener() {
            
            @Override
            public void onClick(View p1) {
                Switch updt = findViewById(R.id.switch1);
                TextView HELP_1 = findViewById(R.id.HELP_ID1);
                HELP_1.setText("none");
                updt.setChecked(false);
                doall(0);
                stop.setEnabled(false);
                ipush("Capture: was interrupted by user");
            }
        });
		update.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View p1)
				{
					lmfao();
					return;
				}
			});}
        protected void AD() {
            CheckBox Advanced = findViewById(R.id.AD_ID);
            Advanced.setChecked(true);
            final TextView HELP_4 = findViewById(R.id.HELP_ID4);
            final TextView textView = findViewById(R.id.textout);
            HELP_4.setText(("on"));
            textView.setVisibility(View.VISIBLE);
            Advanced.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, final boolean isChecked) {
                        if(isChecked) {
                            HELP_4.setText(("on"));
                            textView.setVisibility(View.VISIBLE);
                        } else {
                            HELP_4.setText(("off"));
                            textView.setVisibility(View.INVISIBLE);
                        }}
        });
        }
        
    public void list(String meh) {
        Button list = findViewById(R.id.list);
        TextView tipview = findViewById(R.id.tips);
        TextView HELP_1 = findViewById(R.id.HELP_ID1);
        String TEXT_1 = HELP_1.getText().toString();
        String che = tipview.getText().toString();
        if(meh.equals("1")) {
            if (TEXT_1.equals("none")) {
                
                if (che.isEmpty()) {
            list.setEnabled(true);
            }}
        } else {
            list.setEnabled(false);
        }
    }
    
    public void noti() {
       
            // Create a NotificationManager object.
            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

            // Create a Notification object.
            Notification notification = new Notification();
            notification.tickerText = "Meow!"; // required
            notification.when = System.currentTimeMillis(); // required

            // Set the notification's content title and text.

            // Send the notification.
            notificationManager.notify(1, notification);
        }
    
    public void dialogue(final String zero, final String one, final String two, final String three, final String four, final String five, final String six, final String seven, final String eight, final String nine, final String ten, final String eleven){
            Button list = findViewById(R.id.list);
            list("1");
            list.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        final List items = Arrays.asList(zero, one, two, three, four, five, six, seven, eight, nine, ten, eleven);

                        // Set the dialog title
                        builder.setTitle("Possible Divisors");

                        // Create a ListView to show in the dialog
                        ListView listView = new ListView(MainActivity.this);

                        // Create an ArrayAdapter to populate the ListView
                        ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, items);

                        // Set the adapter on the ListView
                        listView.setAdapter(adapter);
                        
                        // Set the ListView as the dialog content
                        builder.setView(listView);

                        // Create the dialog
                        final AlertDialog dialog = builder.create();

                        // Show the dialog
                        dialog.show();

                        // Add a listener to the ListView so that you can handle the click events on the list items
                        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                                @Override
                                public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4) {
                                    //String slct = zero+"";
                                    EditText custom = findViewById(R.id.custom);
                                    if (p3 == 0) {
                                    custom.setText(zero+"");
                                    } else if (p3 == 1) {
                                        custom.setText(one+"");
                                    } else if (p3 == 2) {
                                        custom.setText(two+"");
                                    } else if (p3 == 3) {
                                        custom.setText(three+"");
                                    } else if (p3 == 4) {
                                        custom.setText(four+"");
                                    } else if (p3 == 5) {
                                        custom.setText(five+"");
                                    } else if (p3 == 6) {
                                        custom.setText(six+"");
                                    } else if (p3 == 7) {
                                        custom.setText(seven+"");
                                    } else if (p3 == 8) {
                                        custom.setText(eight+"");
                                    } else if (p3 == 9) {
                                        custom.setText(nine+"");
                                    } else if (p3 == 10) {
                                        custom.setText(ten+"");
                                    } else if (p3 == 11) {
                                        custom.setText(eleven+"");
                                    }
                                    String a=custom.getText().toString();
                                    //int dotIndex = a.lastIndexOf(".");
                                    //a=a.substring(0, dotIndex);
                                    a=a.substring(0, a.lastIndexOf(" : "));
                                    a=a.substring(0, a.lastIndexOf("."));
                                    custom.setText(a);
                                    ipush("selected "+a+", please update");
                                    KeyEvent backEvent = new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_BACK);
                                    dispatchKeyEvent(backEvent);
                                    dialog.dismiss();
                                
                                }
                            });

                        
                        
                    }
                });
                }
                
        
                
		protected void chk() {
			final Switch updt = findViewById(R.id.switch1);
			updt.setEnabled(false);
			final EditText waittxt = findViewById(R.id.waitbox);
			
			TextWatcher textWatcher = new TextWatcher() {

				@Override
				public void afterTextChanged(Editable p1)
				{}

				@Override
				public void beforeTextChanged(CharSequence s, int start, int count, int after) {
					updt.setEnabled(false);
				}

				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {
					// Do something ile the text is being changed.
					String waitst=waittxt.getEditableText().toString();
					if (waitst.isEmpty()) {
						updt.setEnabled(false);
					} else if (waitst.startsWith("0")) {
						updt.setEnabled(false);
					} else {
						updt.setEnabled(true);
                    }
				}
			};
			waittxt.addTextChangedListener(textWatcher);
            
            updt.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View p1) {
                        lmfao();
                    }
            });
            
			updt.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

					@Override
					public void onCheckedChanged(CompoundButton buttonView, final boolean isChecked) {
                        
                        TextView HELP_3 = findViewById(R.id.HELP_ID3);
                        
						if (isChecked) {
                            ipush("AutoUpdate: ON");
                            HELP_3.setText("on");
                            ProgressBar anime = findViewById(R.id.anim);
                            anime.setVisibility((View.VISIBLE));
                            String waitst = waittxt.getEditableText().toString();
                            int waitint = Integer.parseInt(waitst);
                            int waitint2 = waitint * 1000;
                            
                            bsod(waitint2);
                            
                            
						} else {
                            ProgressBar anime = findViewById(R.id.anim);
                            ipush("AutoUpdate: OFF");
                            HELP_3.setText("off");
                            anime.setVisibility((View.INVISIBLE));
                            
                        }//if and while
					}
			});
		}
        protected void hundred() {
            Button mybatt = findViewById(R.id.mybatt100);
            mybatt.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View p1) {
                        BatteryManager batteryManager = (BatteryManager) getSystemService(BATTERY_SERVICE);
                        int blvl = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                        
                            String var = exec("su -c cat /sys/class/power_supply/battery/charge_counter");
                            int var2 = Integer.parseInt(var);
                            int variable = var2 / 100;
                            if(blvl == 100) {
                                ipush("NICE, YOUR DIVISOR IS: "+variable);
                            } else {
                                ipush("liar, your battery is: "+blvl);
                            }
                        }
                    });
        }
        
    protected void doall(int num) {
        final Button todisable1 = findViewById(R.id.mybatt100);
        final Button todisable2 = findViewById(R.id.clearbtn_id);
        final Button todisable3 = findViewById(R.id.LISTEN_ID);
        final Button todisable4 = findViewById(R.id.clearall);
        final Button todisable5 = findViewById(R.id.updatebtn);
        final Switch todisable6 = findViewById(R.id.switch1);
        final EditText todisable7 = findViewById(R.id.custom);
        final Button todisable8 = findViewById(R.id.list);
        if (num == 1) {
        todisable1.setEnabled(false);
        todisable2.setEnabled(false);
        todisable3.setEnabled(false);
        todisable4.setEnabled(false);
        todisable5.setEnabled(false);
        todisable6.setEnabled(false);
        todisable7.setEnabled(false);
        todisable8.setEnabled(false);
        } else {
        todisable1.setEnabled(true);
        todisable2.setEnabled(true);
        todisable3.setEnabled(true);
        todisable4.setEnabled(true);
        todisable5.setEnabled(true);
        todisable6.setEnabled(true);
        todisable7.setEnabled(true);
        todisable8.setEnabled(true);
        }
    }
        
    protected void listener() {
        final Button LISTEN = findViewById(R.id.LISTEN_ID);
        final EditText SECST = findViewById(R.id.waitbox);
        final Switch updt = findViewById(R.id.switch1);
        final TextView tipview = findViewById(R.id.tips);
        
        
        LISTEN.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View p1) {
                    TextView HELP_1 = findViewById(R.id.HELP_ID1);
                        String var = exec("su -c cat /sys/class/power_supply/battery/charge_counter");
                        HELP_1.setText(var);
                        ipush("Capture: started, set: "+var+"\nwill compare changes each update");
                        LISTEN.setEnabled(false);
                        SECST.setText("2");
                        updt.setChecked(true);
                        doall(1);
                        tipview.setText("Inspecting counter\nwaiting for your battery to drop 0.1%\nthis shouldn't take long");
                }
            });
    }
    
		public void ipush(String newtxt) {
            EditText logview = findViewById(R.id.melog);
            TextView tipview = findViewById(R.id.tips);
            if (newtxt.equals("nuke")) {
                String old=logview.getText().toString();
                old=old.substring(0, old.lastIndexOf('\n'));
                logview.setText(old);
            } else {
			String bqp=logview.getEditableText().toString();
			logview.setText(bqp+"\n"+newtxt);
            tipview.setText(newtxt);
            }
		}
		
		public void isleep(final int seconds) {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... voids) {
                    try {
                        Thread.sleep(seconds);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    return null;
                }
                @Override
                protected void onPostExecute(Void aVoid) {}
            }.execute();
		}
		
    public void bsod(final int seconds) {
        new AsyncTask<Void, Void, Void>() {
            @Override
            int secs = seconds;
            TextView HELP_2 = findViewById(R.id.HELP_ID2);
            TextView HELP_3 = findViewById(R.id.HELP_ID3);
            final TextView yea = findViewById(R.id.yea);
            protected Void doInBackground(Void... voids) {
                try {
                    Thread.sleep(seconds);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                String TEXT3 = HELP_3.getText().toString();
                if(TEXT3.equals("on")) {
                HELP_2.setText(secs+"");
                String TEXT2 = HELP_2.getText().toString();
                lmfao();
                int TEXT_int = Integer.parseInt(TEXT2);
                
                bsod(TEXT_int);
                }
            }
        }.execute();
    }
        
        private void iclear() {
            final EditText logview = findViewById(R.id.melog);
            Button clearbtn = findViewById(R.id.clearbtn_id);
            clearbtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View p1)
                    {
                        logview.setText("Logs:");
                    }
                });}
        
        private void ireset() {
            Button clearall = findViewById(R.id.clearall);
            final EditText logbox = findViewById(R.id.logs);
            final EditText dvide = findViewById(R.id.custom);
            final EditText prcnt = findViewById(R.id.gg);
			final EditText logbox2 = findViewById(R.id.logs2);
            final TextView textView = findViewById(R.id.textout);
            final TextView textView2 = findViewById(R.id.decimal);
			final TextView textView3 = findViewById(R.id.lmao);
            clearall.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View p1)
                    {
                        logbox.setText("Ready");
                        logbox2.setText("Ready");
                        dvide.setText("");
                        prcnt.setText("");
                        textView.setText("");
                        textView2.setText("");
                        textView3.setText("");
                    }
                });
        }
        
    public void blink() {
        final Button update = findViewById(R.id.updatebtn);
        final Button Listen = findViewById(R.id.LISTEN_ID);
        update.setText("Updated");
        update.setEnabled(false);
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                update.setText("Update");
                if (Listen.isEnabled()) {
                    update.setEnabled(true);
                }
            }
        }.execute();
    }
    
    public static String getBetween(String str, String start, String end) {
        int startIndex = str.indexOf(start);
        int endIndex = str.indexOf(end, startIndex + start.length());
        if (startIndex != -1 && endIndex != -1) {
            return str.substring(startIndex + start.length(), endIndex);
        } else {
            return "";
        }
    }
    
    public String exec(String command) {
        String out = "";
        try{
        Process process = Runtime.getRuntime().exec(command);
        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        out=reader.readLine();
        } catch (IOException e) {}
        return out;
    }
    
		public String lmfao() {
			String var = ""; // assign string var
			TextView textView = findViewById(R.id.textout);
			TextView textView2 = findViewById(R.id.decimal);
            TextView HELP_1 = findViewById(R.id.HELP_ID1);
            String TEXT_1 = HELP_1.getText().toString();
			TextView textView3 = findViewById(R.id.lmao);
			TextView tipview = findViewById(R.id.tips);
            Button stop = findViewById(R.id.stawp);
            String che = tipview.getText().toString();
            if (che.endsWith("Needs root!")) {
            if(TEXT_1.equals("none")) {
            //stop.setEnabled(true);
            }
            tipview.setText(""); }
			EditText logbox = findViewById(R.id.logs);
			EditText dvide = findViewById(R.id.custom);
			EditText prcnt = findViewById(R.id.gg);
			EditText logbox2 = findViewById(R.id.logs2);
            TextView HELP_2 = findViewById(R.id.HELP_ID2);
            String TEXT_2 = HELP_2.getText().toString();
            Button LISTEN = findViewById(R.id.LISTEN_ID);
            Switch updt = findViewById(R.id.switch1);
            final TextView yea = findViewById(R.id.yea);
            final EditText waitbox = findViewById(R.id.waitbox);
				// set dvide visible
				// updt.setVisibility(View.VISIBLE);
				prcnt.setVisibility(View.VISIBLE);
				dvide.setVisibility(View.VISIBLE);
				String ctext = dvide.getText().toString();
				String ctext2 = "";
				String dvideby = "";
				if (ctext != null && !ctext.isEmpty()) {
					ctext2 = "done"; // custom
					dvideby = ctext;
					} else { // default divisor
						ctext2 = "2000";
						ctext = "none";
						dvideby = ctext2;
				}
                
				// execute command and assign output to var
				var = exec("su -c cat /sys/class/power_supply/battery/charge_counter");
				// execute command and assign output to var3
				String var3 = exec("su -c dumpsys battery | grep 'charge counter' | sed 's/charge counter: //'");
				// get battery level and assign to blevel
				BatteryManager batteryManager = (BatteryManager) getSystemService(BATTERY_SERVICE);
				int blvl = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
				String blevel = blvl+"";
				
				// make int variants of strings, export decimal number
				int varint = Integer.parseInt(var); // 548000
				int ctextint = Integer.parseInt(dvideby);
				int varint2 = varint / ctextint; // 274
				String sure = varint2 + ""; // same
				float float1 = Float.parseFloat(sure);
				float1 = float1 / 10;
                
				double opm1 = varint / (blvl - 0.1) / 10;
				double op0 = varint / (blvl + 0.0) / 10;
				double op1 = varint / (blvl + 0.1) / 10;
				double op2 = varint / (blvl + 0.2) / 10;
				double op3 = varint / (blvl + 0.3) / 10;
				double op4 = varint / (blvl + 0.4) / 10;
				double op5 = varint / (blvl + 0.5) / 10;
				double op6 = varint / (blvl + 0.6) / 10;
				double op7 = varint / (blvl + 0.7) / 10;
				double op8 = varint / (blvl + 0.8) / 10;
				double op9 = varint / (blvl + 0.9) / 10;
				double op10 = varint / (blvl + 1.0) / 10;
                
				// for first and last values
				int blvlp = blvl + 1;
				int blvlm = blvl - 1;
                String w2 = " : ";
                String w = " : "+blvl+".";
                dialogue(opm1+w2+blvlm+".9", op0+w+"0", op1+w+"1", op2+w+"2", op3+w+"3", op4+w+"4", op5+w+"5", op6+w+"6", op7+w+"7", op8+w+"8", op9+w+"9", op10+w2+blvlp+".0");
                

				textView.setText("counter:\n"+var+"\n\nratio:\n"+sure+"\n\ndebug:\n"+"20000\n"+blevel+"\n\n"+"attmpt:\n"+float1+"\n\n"+"matches:\n"+var3+"\n\n"+"Divisor:\n"+ctext2+"\n\n"+"Custom divisor:\n"+ctext+"\n\n"+"Wait interval: \n"+TEXT_2+"\n\n"+"Captured: \n"+TEXT_1);
				textView2.setText("");                                               
				textView3.setText("");
				prcnt.setText(float1+"%");
                
                
				logbox.setText("psble dvide:\n"+opm1+"\n"+op0+"\n"+op1+"\n"+op2+"\n"+op3+"\n"+op4+"\n"+op5+"\n"+op6+"\n"+op7+"\n"+op8+"\n"+op9+"\n"+op10);
				logbox2.setText("prcnt:\n"+blvlm+".9"+"\n"+blvl+".0"+"\n"+blvl+".1"+"\n"+blvl+".2"+"\n"+blvl+".3"+"\n"+blvl+".4"+"\n"+blvl+".5"+"\n"+blvl+".6"+"\n"+blvl+".7"+"\n"+blvl+".8"+"\n"+blvl+".9"+"\n"+blvlp+".0");
                //ipush("DB: updated");
                
                if(yea.getText().toString().equals("yes")){
                    // push notification
                    String percent = prcnt.getText().toString();
                    String lel="";
                    if(waitbox.getText().toString().isEmpty()) {} else if(updt.isChecked()) {
                    lel = " | Refresh interval: " + waitbox.getText().toString() + "s";
                    }
                    exec("su -lp 2000 -c cmd notification post -S bigtext -t 'DecimalBattery' 'DecimalPercentage' 'Battery Percentage: " + percent + lel + "'");
                }
                blink();
                if(TEXT_1.equals("none")) {
                    //pass
                } else {
                    if(TEXT_1.equals(var)) {
                        String lastline = tipview.getText().toString();
                        if (lastline.endsWith("]")){
                            String nom = getBetween(lastline, "[", "]");

                            int nomi = Integer.parseInt(nom);
                            ++nomi; nom=String.valueOf(nomi);
                            ipush("nuke");
                            ipush("Capture: unchanged ("+var+") ["+nom+"]");
                        } else {
                            ipush("Capture: unchanged ("+var+") [0]");
                        }
                        //String st = tipview.getText().toString();
                        //String lmao=st.substring(0, st.lastIndexOf('\n'));
                    } else {
                        int TEXT_1_int = Integer.parseInt(TEXT_1);
                        int susvar = (varint - TEXT_1_int);
                        ipush("Capture: changed \nCapture: detected change: "+susvar);
                        Toast.makeText(MainActivity.this, "Capture done, please update", Toast.LENGTH_SHORT).show();
                        ipush("Capture: cleared");
                        HELP_1.setText("none");
                        LISTEN.setEnabled(true);
                        int susvar_abs = 6969;
                        if(susvar <= 0) {
                            susvar_abs = (susvar * -1);
                        } else {
                            susvar_abs = susvar;
                        }
                        ipush("DB: suspected divisor: "+susvar_abs);
                        stop.setEnabled(false);
                        String susvar_abs_st = susvar_abs+"";
                            dvide.setText(susvar_abs_st);
                            tipview.setText("Attempted value "+susvar_abs_st+"\nas custom divisor, please update");
                        updt.setChecked(false);
                        ipush("AutoUpdate: was interrupted by Capture");
                        doall(0);
                        
                    }
                }
            return prcnt.getText().toString();
		}
	}

